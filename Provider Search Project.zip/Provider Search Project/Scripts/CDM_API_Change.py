import tkinter as tk
from tkinter import *
from tkinter import filedialog
from tkinter.filedialog import askdirectory
import tkinter.ttk as ttk
import pandas as pd
import numpy as np
import traceback
from tkinter import messagebox
import openpyxl
import datetime
import glob
import shutil
import time
from datetime import datetime
import win32com
import win32com.client
import re
import sys
import os
# from selenium import webdriver
# from selenium.webdriver.common.by import By
# from selenium.webdriver.common.keys import Keys
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# from selenium.webdriver.chrome.options import Options

try:

    root = Tk()
    root.geometry("800x700+220+160")
    root.title('Provider Search')
    root.resizable(0, 0)

    style = ttk.Style()
    style.theme_use("default")
    style.configure("Treeview", background="Light yellow", foreground="black", fieldbackground="light yellow")
    style.map("Treeview", background=[("selected", "green")])

    xl = StringVar()
    current_var = tk.StringVar()

    regex_postfix_removal = '( ,| |,)+(LLC|INC|DBA|PC|PLLC|P.C|LCSW|LMHC|LPC|MFT|MS|LCSW-C|NSS|M.S|M.A|P.L.L.C|PSYDPA)'


    def remove_char(ch):
        ch = ch.rstrip(".")
        ch = ch.replace(",", "").replace(".", "").replace("/", "")
        ch = re.sub(regex_postfix_removal, '', ch, re.IGNORECASE)
        return ch


    abbr_df = pd.read_excel(os.path.join(os.getcwd(), r'Abbreviation_Sheet.xlsx'))
    abbr_df.set_index('abbreviation', inplace=True)


    def replace_abbreviations(text):
        if isinstance(text, str):
            words = text.split()
            words = [abbr_df.loc[word, 'expansion'] if word in abbr_df.index else word for word in words]
            text = ' '.join(words)
        return text


    def closeBtn():
        root.destroy()


    def sheet_data():
        try:
            excel_folder_lst = ["Temp_Files", "Output_File"]

            global df
            df1 = pd.read_excel(input3.get(), sheet_name=current_var.get())
            df = pd.DataFrame(df1)

            if 'FIRST NAME' in df.columns:
                df['MIDDLE INITIAL'] = df['MIDDLE INITIAL'].fillna("NO")
                df['MIDDLE INITIAL'] = df['MIDDLE INITIAL'].replace('NO', "")
                df['FIRST NAME'] = df['FIRST NAME'].fillna(" ")
                df[["FIRST NAME", "LAST NAME"]] = df[["FIRST NAME", "LAST NAME"]].astype(str)
                df['PROVIDER'] = df['FIRST NAME'] + ' ' + df['MIDDLE INITIAL'] + ' ' + df['LAST NAME']
                df['FIRST NAME'] = df['FIRST NAME'].str.upper()
                df['LAST NAME'] = df['LAST NAME'].str.upper()

                cols = df.columns.tolist()
                cols = cols[-1:] + cols[:-1]
                df = df[cols]

                df[["NPI", "ZIP", "PHONE"]] = (df[["NPI", "ZIP", "PHONE"]].fillna(0)).astype('int64')
                df[["STREET", "SUITE", "CITY", "STATE"]] = df[
                    ["STREET", "SUITE", "CITY", "STATE"]].astype(str)
                dfTemp = pd.DataFrame(df1)
            else:
                df[["NPI", "ZIP", "PHONE"]] = (df[["NPI", "ZIP", "PHONE"]].fillna(0)).astype('int64')
                df[["STREET", "SUITE", "CITY", "STATE"]] = df[
                    ["STREET", "SUITE", "CITY", "STATE"]].astype(str)

                dfTemp = pd.DataFrame(df1)

            dfTemp.NPI = dfTemp.NPI.fillna(0).astype(int)
            dfTemp.NPI = dfTemp.NPI.replace(0, '')
            dfTemp = dfTemp.fillna("")

            if len(dfTemp) > 0:
                global xyz
                clear_treeview()
                tree["column"] = list(dfTemp.columns)
                tree["show"] = "headings"
                for col in tree["column"]:
                    tree.heading(col, text=col)
                    df_rows = dfTemp.to_numpy().tolist()
                for row in df_rows:
                    tree.insert("", "end", values=row)
                    if xyz == 1:
                        treeScroll = ttk.Scrollbar(tblFrame, orient="vertical", command=tree.yview)
                        treeScrollH = ttk.Scrollbar(tblFrame, orient="horizontal", command=tree.xview)
                        xyz = 2
                    else:
                        tree.configure(xscrollcommand=tree.yview)
                        tree.configure(yscrollcommand=tree.yview)
                    tree.configure(xscrollcommand=treeScrollH.set, yscrollcommand=treeScroll.set)
                    treeScroll.pack(side=LEFT, fill=BOTH)
                    treeScrollH.pack(side=BOTTOM, Fill=BOTH)
                    tree.pack()
                    tree.focus_set()
                    children = tree.get_children()
                    if children:
                        tree.focus(children[0])
                        tree.selection_set(children[0])

        except Exception as e:

            traceback.print_exc(file=sys.stdout)


    def clear_treeview():
        tree.delete(*tree.get_children())


    def selectItem(e):
        try:
            global x
            global curItem
            curItem = tree.focus()
            x = {}
            x = tree.item(curItem)


        except Exception as e:
            traceback.print_exc(file=sys.stdout)


    def open_file():
        try:
            global filepath
            file = filedialog.askopenfile(mode="r", filetypes=[("Excel Files", "*.xlsx *.csv")])
            if file:
                filepath = os.path.abspath(file.name)
                input3.config(state="normal")
                input3.insert(0, str(filepath))

                wb = openpyxl.load_workbook(filepath)
                current_var.set(wb.sheetnames[0])
                sheetCombo["values"] = wb.sheetnames


            else:
                input3.config(state="normal")
                input3.insert(0, "*** Select a File ***")
                input3.config(state="disabled")
        except Exception as e:

            traceback.print_exc(file=sys.stdout)


    def exportfile():
        try:
            import ctypes
            folderpath = askdirectory()
            shutil.copy(os.path.join(os.getcwd(), "Output_File\Provider_Data_Extracted Updated.xlsx"),
                        folderpath + "//My_Output.xlsx")

            labelx.configure(text="File exported to: " + folderpath + "/My_Output.xlsx")
            ctypes.windll.user32.MessageBoxW(0, "File exported to:" + folderpath, "Information Only", 1)
        except Exception as e:

            traceback.print_exc(file=sys.stdout)


    def update_progress_label():

        return f"{pb['value']}%"


    def progress():
        if pb['value'] < 100:
            pb['value'] += 12.5
            root.update_idletasks()

            time.sleep(1)
            value_label['text'] = update_progress_label()


    def code_search():
        try:
            start_time = datetime.now()

            labelz.configure(text="Current Status--Processing", fg="brown")
            root.update()

            output_file = "Output File"
            archive_file = "Archive"
            temp_file = "Temp_Files"
            error_file = "Error Out"

            if getattr(sys, 'frozen', False):
                application_path = os.path.dirname(sys.executable)
                running_mode = "Frozen/executable"
            else:
                try:
                    app_full_path = os.path.realpath(__file__)
                    application_path = os.path.dirname(app_full_path)
                    running_mode = "Non-interative"
                except NameError:
                    application_path = os.getcwd()
                    running_mode = 'Interactive'

            global output_full_path
            output_full_path = os.path.join(application_path, output_file)
            temp_full_path = os.path.join(application_path, temp_file)

            driver = webdriver.Chrome(executable_path='' + str(application_path) + '\chromedriver.exe')
            driver.minimize_window()

            df['index_col'] = range(1, len(df) + 1)

            print('\n' + str(filepath) + '_Processing Starts')


        except Exception as e:
            traceback.print_exc(file=sys.stdout)

        def Nppes():
            df_input = pd.read_excel(input_file)
            npi_ids = df_input.iloc[:, 0].tolist()  # Assumes NPI IDs are in the first column

            combined_data = []  # List to hold combined data

            for npi_id in npi_ids:
                url = f"https://npiregistry.cms.hhs.gov/api/?number={npi_id}&enumeration_type=&taxonomy_description=&name_purpose=&first_name=&use_first_name_alias=&last_name=&organization_name=&address_purpose=&city=&state=&postal_code=&country_code=&limit=&skip=&pretty=&version=2.1"

                response = requests.get(url)

                # Access response content
                content = response.content

                # Access response JSON
                json_data = response.json()

                # Check response status code
                status_code = response.status_code

                # Check response headers
                headers = response.headers

                data = json.loads(response.text)

                providers = data['results']
                # print(providers)
                for provider in providers:
                    npi = provider['number']
                    try:
                        display_name = provider['basic']['organization_name']
                        organizational_subpart = provider['basic']['organizational_subpart']
                        mailing_address = provider['addresses'][0]['address_1']
                        mailing_city = provider['addresses'][0]['city']
                        mailing_state = provider['addresses'][0]['state']
                        mailing_postal_code = provider['addresses'][0]['postal_code']
                        mailing_phone_number = provider['addresses'][0]['telephone_number']
                        primary_address = provider['addresses'][1]['address_1']
                        primary_city = provider['addresses'][1]['city']
                        primary_state = provider['addresses'][1]['state']
                        primary_postal_code = provider['addresses'][1]['postal_code']
                        if 'telephone_number' in provider['addresses'][1]:
                            primary_phone_number = provider['addresses'][1]['telephone_number']
                        else:
                            primary_phone_number = "N/A"
                        enumeration_type = provider['enumeration_type']
                        enumeration_date = provider['basic']['enumeration_date']
                        last_updated = provider['basic']['last_updated']
                        status = provider['basic']['status']
                        authorized_official_first_name = provider['basic']['authorized_official_first_name']
                        authorized_official_last_name = provider['basic']['authorized_official_last_name']
                        if 'authorized_official_middle_name' in provider['basic']:
                            authorized_official_middle_name = provider['basic']['authorized_official_middle_name']
                        else:
                            authorized_official_middle_name = "N/A"
                        authorized_official_telephone_number = provider['basic']['authorized_official_telephone_number']
                        authorized_official_title_or_position = provider['basic'][
                            'authorized_official_title_or_position']
                        specialty = provider['taxonomies'][0]['desc']
                    except:
                        f_name = provider['basic']['first_name']
                        l_name = provider['basic']['last_name']
                        if 'middle_name' in provider['basic']:
                            m_name = provider['basic']['middle_name']
                        else:
                            m_name = ""
                        if 'credential' in provider['basic']:
                            c_name = provider['basic']['credential']
                        else:
                            c_name = ""
                        display_name = f_name + " " + m_name + " " + l_name + " " + c_name
                        organizational_subpart = ""
                        mailing_address = provider['addresses'][0]['address_1']
                        mailing_city = provider['addresses'][0]['city']
                        mailing_state = provider['addresses'][0]['state']
                        mailing_postal_code = provider['addresses'][0]['postal_code']
                        mailing_phone_number = provider['addresses'][0]['telephone_number']
                        primary_address = provider['addresses'][1]['address_1']
                        primary_city = provider['addresses'][1]['city']
                        primary_state = provider['addresses'][1]['state']
                        primary_postal_code = provider['addresses'][1]['postal_code']
                        if 'telephone_number' in provider['addresses'][1]:
                            primary_phone_number = provider['addresses'][1]['telephone_number']
                        else:
                            primary_phone_number = "N/A"
                        enumeration_type = provider['enumeration_type']
                        enumeration_date = provider['basic']['enumeration_date']
                        last_updated = provider['basic']['last_updated']
                        status = provider['basic']['status']
                        authorized_official_first_name = ""
                        authorized_official_last_name = ""
                        if 'authorized_official_middle_name' in provider['basic']:
                            authorized_official_middle_name = ""
                        else:
                            authorized_official_middle_name = ""
                        authorized_official_telephone_number = ""
                        authorized_official_title_or_position = ""
                        specialty = provider['taxonomies'][0]['desc']
                    # print(specialty)
                    important_details = {
                        "NPI": npi, "PROVIDER_NAME": display_name, 'ORGANIZATIONAL_SUBPART': organizational_subpart,
                        "MAILING_ADDRESS": mailing_address, "MAILING_CITY": mailing_city,
                        "MAILING_STATE": mailing_state, "MAILING_POSTAL_CODE": mailing_postal_code,
                        "MAILING_PHONE_NUMBER": mailing_phone_number, "PRIMARY_PRACTICE_ADDRESS": primary_address,
                        "PRIMARY_PRACTICE_CITY": primary_city, "PRIMARY_PRACTICE_STATE": primary_state,
                        "PRIMARY_PRACTICE_POSTAL_CODE": primary_postal_code,
                        "PRIMARY_PRACTICE_PHONE_NUMBER": primary_phone_number, "ENUMERATION_TYPE": enumeration_type,
                        "ENUMERATION_DATE": enumeration_date,
                        "LAST_UPDATED": last_updated, "STATUS": status,
                        "AUTHORIZED_OFFICIAL_FIRST_NAME": authorized_official_first_name,
                        "AUTHORIZED_OFFICIAL_LAST_NAME": authorized_official_last_name,
                        "AUTHORIZED_OFFICIAL_MIDDLE_NAME": authorized_official_middle_name,
                        "AUTHORIZED_OFFICIAL_TELEPHONE_NUMBER": authorized_official_telephone_number,
                        "AUTHORIZED_OFFICIAL_TITLE_OR_POSITION": authorized_official_title_or_position,
                        "SPECIALTY": specialty}
                    df = pd.DataFrame.from_dict(important_details, orient='index')
                    df = df.transpose()
                    # print(df.to_markdown())
                    combined_data.append(df)

            combined_df = pd.concat(combined_data, axis=0)
            output_file = "F:\\Python Code\\POC_API\\Nppes\\Nppes_doctor_details.xlsx"
            combined_df.to_excel(output_file, index=False)
            print(combined_df.to_markdown())
            # Save the DataFrame to an Excel file
            combined_df.to_excel('F:\\Python Code\\POC_API\\Nppes\\Nppes_doctor_details.xlsx', index=False)

            labela.configure(text="NPPES Website Module completed!")



#         def Hippaspace_Individual():
#
#             try:
#                 print("\n****Hippa Space Module has started****")
#                 i_List = []
#                 providername = []
#                 myphone = []
#                 State = []
#                 State_Code = []
#                 Index = []
#
#                 Lst = ["DBA", "INC", "LLC", "PLLC", "PC", "SC", "Inc", "P.C."]
#
#                 if 'FIRST NAME' in df.columns:
#                     individual_df = df['PROVIDER']
#                 else:
#                     org_df = df['PROVIDER']
#                     individual_df = pd.DataFrame()
#
#                 for i in individual_df.index:
#                     i_List.append(individual_df[i].strip() + ' ' + df['STATE'][i].strip() + ' ' + 'HIPAASPACE')
#                     Index.append(df['index_col'][i])
#
#                 if 'FIRST NAME' in df.columns:
#                     for i in i_List:
#                         try:
#                             driver.minimize_window()
#                             driver.get("https://google.com/")
#
#                             driver.minimize_window()
#                             driver.find_element_by_xpath("//*[@class='gLFyf']").send_keys(str(i))
#                             driver.find_element_by_xpath(
#                                 "/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]").submit()
#
#                             driver.find_element_by_xpath("//*[contains(@href, 'www.hipaaspace.com/')]").click()
#
#                             Name = driver.find_element_by_tag_name("h2").text
#
#                             driver.execute_script("window.scrollTo(0, window.scrollY +1000)")
#
#                             Phone_no = driver.find_element_by_xpath(
#                                 "//a[contains(@title, 'Phone to NPI crosswalking')]").text
#
#                             driver.execute_script("window.scrollTo(0, window.scrollY +1000)")
#                             Address = driver.find_element_by_xpath(
#                                 '//*[@id="masterForm"]/div[3]/div/div/main/div/div[8]/div[1]/div/table/tbody/tr/td/p[4]/strong').text
#
#                             providername.append(Name)
#                             myphone.append(Phone_no)
#                             State.append(Address)
#
#                             driver.implicitly_wait(5)
#
#                             driver.back()
#
#                         except:
#                             providername.append("No Result Found")
#                             myphone.append("No Result Found")
#                             State.append("No Result Found")
#                             driver.back()
#
#                     for j in State:
#
#                         if j == "No Result Found":
#                             State_Code.append("No Result Found")
#                             continue
#
#                         State_Code.append(j)
#
#                     Hippaspace_Individual = {"PROVIDER": providername, "ADDRESS": State_Code,
#                                              "Phone": myphone, "index_col": Index}
#
#                     hippa_ind = pd.DataFrame(Hippaspace_Individual)
#
#                     hippa_ind.to_excel(temp_full_path + "\Hippa_ind.xlsx", index=False)
#
#                     df_output = hippa_ind
#
#                     df['New'] = df['PROVIDER'].str.strip()
#                     df['New'] = df['New'].astype(str)
#                     df['New'] = df['New'].str.upper()
#                     df_new = df['New']
#                     df_new = df_new.to_frame(name='New')
#                     df_new['New'] = df['New'].str.upper()
#                     df_new['index_col'] = df['index_col']
#
#                     final = pd.concat([df, df_new], axis=1)
#
#                     final = final.loc[:, ~final.columns.duplicated()]
#
#                     df_output["New"] = df_output['PROVIDER']
#                     df_output["New"] = df_output["New"].astype(str)
#
#                     pat_lname = f"({'|'.join(df['LAST NAME'])})"
#                     pat_fname = f"({'|'.join(df['FIRST NAME'])})"
#                     df_output['LAST NAME'] = df_output['New'].str.extract(pat=pat_lname)
#                     df_output['FIRST NAME'] = df_output['New'].str.extract(pat=pat_fname)
#                     df_output.loc[df_output['LAST NAME'].isna(), 'LAST NAME'] = np.NAN
#                     df_output.loc[df_output['FIRST NAME'].isna(), 'FIRST NAME'] = np.NAN
#                     Vlookup = df.merge(df_output, left_on=['LAST NAME', 'FIRST NAME'],
#                                        right_on=['LAST NAME', 'FIRST NAME'], how='left')
#                     Vlookup = Vlookup.drop(["PROVIDER_y", "New_x", "index_col_y", "New_y"], axis=1)
#
#                     df_final = Vlookup.drop_duplicates()
#                     df_final.rename(columns={'index_col_x': 'index_col', 'PROVIDER_x': 'PROVIDER'}, inplace=True)
#
#                     df_ph = df_final.groupby("index_col")["Phone"].apply(lambda x: x.unique()).reset_index()
#
#                     df_add = df_final.groupby("index_col")["ADDRESS"].apply(lambda x: x.unique()).reset_index()
#
#                     df_hippa = pd.merge(df, df_ph, on='index_col', how='left')
#
#                     df_hippa = pd.merge(df_hippa, df_add, on='index_col', how='left')
#                     df_hippa = df_hippa.drop(['New'], axis=1)
#                     df_hippa.rename(columns={'Phone': 'Hippaspace_Phone_No'}, inplace=True)
#
#                     df_hippa.rename(columns={'ADDRESS': 'Hippaspace Address'}, inplace=True)
#                     df_hippa = df_hippa.fillna("")
#
#                     df_hippa.to_exeel(temp_full_path + '\Matched Hippa_Ind_Output.xlsx', index=False, header=True)
#
#             except Exception as e:
#                 traceback.print_exc(file=sys.stdout)
#
#         def Hippaspace_Organization():
#             try:
#                 org_List = []
#                 providername1 = []
#                 myphone1 = []
#                 State1 = []
#                 State_Code1 = []
#                 Index = []
#                 Lst = ["DBA", "INC", "LLC", "PLLC", "PC", "SC", "Inc"]
#
#                 if 'FIRST NAME' in df.columns:
#                     individual_df = df['PROVIDER']
#                     org_df = pd.DataFrame()
#                 else:
#                     org_df = df['PROVIDER']
#
#                     for i in org_df.index:
#                         org_List.append(org_df[i].strip() + ' ' + df['STATE'][i].strip() + ' ' + 'HIPAASPACE')
#                         Index.append(df['index_col'][i])
#
#                     for j in org_List:
#
#                         try:
#
#                             driver.get("https://google.com/")
#
#                             driver.minimize_window()
#
#                             driver.find_element_by_xpath("//*[@class='gLFyf']").send_keys(str(j))
#
#                             driver.find_element_by_xpath(
#                                 "/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]").submit()
#
#                             driver.find_element_by_xpath("//*[contains(@href, 'www.hipaaspace.com/')]").click()
#                             driver.implicitly_wait(10)
#                             driver.execute_script("window.scrollTo(0, window.scrollY +1000)")
#                             Name1 = driver.find_element_by_tag_name(
#                                 "//*[@id='masterForm']/div[3]/div/div/main/div/div[6]/div/h2").text
#
#                             driver.execute_script("window.scrollTo(0, window.scrollY +1000)")
#
#                             Phone_no1 = driver.find_element_by_xpath(
#                                 "//a[contains(@title, 'Phone to NPI crosswalking')]").text
#
#                             driver.execute_script("window.scrollTo(0, window.scrollY +1000)")
#                             Address1 = driver.find_element_by_xpath(
#                                 '//*[@id="masterForm"]/div[3]/div/div/main/div/div[8]/div[1]/div/table/tbody/tr/td/p[4]/strong').text
#
#                             providername1.append(Name1)
#                             myphone1.append(Phone_no1)
#
#                             State1.append(Address1)
#
#                             driver.implicitly_wait(5)
#
#                             driver.back()
#
#                         except:
#                             providername1.append("No Result Found")
#                             myphone1.append("No Result Found")
#                             State1.append("No Result Found")
#                             driver.back()
#
#                     for j in State1:
#
#                         if j == "No Result Found":
#                             State_Code1.append("No Result Found")
#
#                             continue
#
#                         State_Code1.append(j)
#
#                     Hippaspace_organization = {"PROVIDER": providername1, "ADDRESS": State_Code1,
#                                                "Phone": myphone1, "index_col": Index}
#
#                     hippa_org = pd.DataFrame(Hippaspace_organization)
#
#                     hippa_org.to_excel(temp_full_path + "\Hippa_org.xlsx", index=False)
#
#                     df_output = hippa_org
#                     df['PROVIDER'] = df['PROVIDER'].str.upper()
#                     df['PROVIDER'] = df['PROVIDER'].apply(replace_abbreviations)
#                     List1 = ["DBA", "INC", "LLC", "PLLC", "PC", "SC", "LMHC", ".", "P.C", "Inc", ","]
#
#                     df['PROVIDER'] = df['PROVIDER'].str.upper()
#                     df['PROVIDER'] = df['PROVIDER'].apply(replace_abbreviations)
#                     df['New'] = df['PROVIDER'].str.strip()
#                     df['New'] = df['New'].str.upper()
#                     df['New'] = df['PROVIDER'].replace('\s+', '', regex=True)
#                     df['New'] = df.New.apply(lambda ch: remove_char(ch))
#                     df['New'] = df['New'].str.upper()
#
#                     df_new = df['New']
#                     df_new = df_new.to_frame(name='New')
#                     df_new['New'] = df['New'].str.upper()
#                     df_new['index_col'] = df['index_col']
#                     df['New'] = df['NEW'].replace('\s+', '', regex=True)
#                     df['New'] = df.New.apply(lambda ch: remove_char(ch))
#
#                     final = pd.concat([df, df_new], axis=1)
#
#                     final = final.loc[:, ~final.columns.duplicated()]
#
#                     df_output["New"] = df_output['PROVIDER']
#                     df_output["New"] = df_output["New"].astype(str)
#                     df_output['New'] = df_output['New'].str.upper()
#                     df_output['New'] = df_output['NEW'].replace('\s+', '', regex=True)
#                     df_output['New'] = df_output.New.apply(lambda ch: remove_char(ch))
#
#                     Vlookup = df.merge(df_new, df_output, on=['NEW', 'index_col'], how='inner')
#
#                     final_output = Vlookup.drop_duplicates()
#
#                     df_final = pd.merge(final, final_output, on=['New', 'index_col'], how="left")
#
#                     df_final = df_final.drop(["New"], axis=1)
#
#                     df_final.rename(columns={'STATE_x': 'STATE', 'PROVIDER_x': 'PROVIDER'}, inplace=True)
#
#                     df_ph = df_final.groupby("index_col")["Phone"].apply(lambda x: x.unique()).reset_index()
#
#                     df_add = df_final.groupby("index_col")["ADDRESS"].apply(lambda x: x.unique()).reset_index()
#
#                     df_hippa1 = pd.merge(df, df_ph, on='index_col', how='left')
#
#                     df_hippa1 = pd.merge(df_hippa1, df_add, on='index_col', how='left')
#                     df_hippa1 = df_hippa1.drop(['New'], axis=1)
#                     df_hippa1.rename(columns={'Phone': 'Hippaspace_Phone_No'}, inplace=True)
#
#                     df_hippa1.rename(columns={'ADDRESS': 'Hippaspace_Address'}, inplace=True)
#                     df_hippa1 = df_hippa1.fillna("")
#
#                     df_hippa1.to_exeel(temp_full_path + '\Matched Hippa_Org_Output.xlsx', index=False, header=True)
#
#                 end_time = datetime.now()
#
#                 print("Hippa Space Website Module completed successfully!")
#
#                 labelb.configure(text="Hippa Space Website Module completed!")
#                 progress()
#                 root.update()
#
#             except Exception as e:
#                 labelb.configure(text="Hippa Space Website Module completed!", fg="brown")
#                 progress()
#                 root.update()
#                 traceback.print_exc(file=sys.stdout)
#
#         def Webmd_individual():
#             try:
#
#                 print("\n****Webmd Module has started****")
#
#                 start_time = datetime.now()
#
#                 search_Data = []
#
#                 Provider_Contact_Numb = []
#
#                 State = []
#
#                 State_Code = []
#                 Index = []
#                 i_List = []
#
#                 if 'FIRST NAME' in df.columns:
#                     individual_df = df['PROVIDER']
#
#
#
#                 else:
#                     org_df = df['PROVIDER']
#                     individual_df = pd.DataFrame()
#
#                 for i in individual_df.index:
#                     i_List.append(individual_df[i].strip() + ' ' + df['STATE'][i].strip() + ' ' + 'WEBMD')
#                     Index.append(df['index_col'][i])
#
#                 if 'FIRST NAME' in df.columns:
#
#                     for i in i_List:
#
#                         try:
#                             driver.get("https://google.com/")
#
#                             driver.minimize_window()
#
#                             driver.find_element_by_xpath("//*[@class='gLFyf']").send_keys(str(i))
#
#                             driver.find_element_by_xpath(
#                                 "/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]").submit()
#
#                             driver.find_element_by_xpath("//*[contains(@href, 'https://doctor.webmd.com/')]").click()
#
#                             driver.implicitly_wait(10)
#
#                             try:
#                                 name = driver.find_element_by_xpath(
#                                     "//*[@id='app']/main/div[1]/article/div[1]/div[2]/h1").text
#                                 search_Data.append(name)
#                             except:
#                                 search_Data.append("")
#
#                             try:
#                                 st = driver.find_element_by_xpath(
#                                     "//*[@id='app']/main/div[1]/article/div[3]/div[1]/div[3]/div[2]/div[2]/p").text
#                                 State_Code.append(st)
#                             except:
#                                 State_Code.append("")
#
#                             try:
#                                 cn = driver.find_element_by_xpath(
#                                     "//*[@id='office-info ]/div/div[2]/div[2]/div/div[1]/div[4]/a").text
#                                 Provider_Contact_Numb.append(cn)
#                             except:
#                                 Provider_Contact_Numb.append("")
#
#                             driver.implicitly_wait(10)
#
#                             driver.back()
#                         except:
#
#                             search_Data.append("None")
#                             State_Code.append("None")
#                             Provider_Contact_Numb.append("None")
#
#                     Webmd_individual = {"PROVIDER": search_Data, "ADDRESS": State_Code,
#                                         "Phone": Provider_Contact_Numb, "index_col": Index}
#
#                     webmd_ind = pd.DataFrame(Webmd_individual)
#
#                     webmd_ind.to_excel(temp_full_path + "\Webmd_ind.xlsx", index=False)
#                     df_output = pd.read_excel(temp_full_path + "\Webmd_ind.xlsx")
#                     df_output = df_output.astype(str)
#
#                     df['New'] = df['PROVIDER'].str.strip()
#                     df['New'] = df['New'].str.upper()
#
#                     df['New'] = df.New.apply(lambda ch: remove_char(ch))
#
#                     df_new = df['New']
#                     df_new = df_new.to_frame(name='New')
#                     df_new['New'] = df['New'].str.upper()
#                     df_new['index_col'] = df['index_col']
#
#                     final = pd.concat([df, df_new], axis=1)
#
#                     final = final.loc[:, ~final.columns.duplicated()]
#
#                     df_output["New"] = df_output['PROVIDER']
#                     df_output["New"] = df_output['New'].str.upper()
#
#                     df_output["New"] = df_output.New.apply(lambda ch: remove_char(ch))
#
#                     pat_lname = f"({'|'.join(df['LAST NAME'])})"
#                     pat_fname = f"({'|'.join(df['FIRST NAME'])})"
#                     df_output['LAST NAME'] = df_output['New'].str.extract(pat=pat_lname)
#                     df_output['FIRST NAME'] = df_output['New'].str.extract(pat=pat_fname)
#                     df_output.loc[df_output['LAST NAME'].isna(), 'LAST NAME'] = np.NAN
#                     df_output.loc[df_output['FIRST NAME'].isna(), 'FIRST NAME'] = np.NAN
#                     Vlookup = df.merge(df_output, left_on=['LAST NAME', 'FIRST NAME'],
#                                        right_on=['LAST NAME', 'FIRST NAME'], how='left')
#                     Vlookup = Vlookup.drop(["PROVIDER_y", "New_x", "index_col_y", "New_y"], axis=1)
#
#                     df_final = Vlookup.drop_duplicates()
#                     df_final.rename(columns={'index_col_x': 'index_col', 'PROVIDER_x': 'PROVIDER'}, inplace=True)
#
#                     df_ph = df_final.groupby("index_col")["Phone"].apply(lambda x: x.unique()).reset_index()
#
#                     df_add = df_final.groupby("index_col")["ADDRESS"].apply(lambda x: x.unique()).reset_index()
#
#                     df_webmd = pd.merge(df, df_ph, on='index_col', how='left')
#
#                     df_webmd = pd.merge(df_webmd, df_add, on='index_col', how='left')
#                     df_webmd = df.webmd.drop(['New'], axis=1)
#                     df_webmd.rename(columns={'Phone': 'Webmd_Phone_No'}, inplace=True)
#
#                     df_webmd.rename(columns={'ADDRESS': 'Webmd_Address'}, inplace=True)
#                     df_webmd = df_webmd.fillna("")
#
#                     df_webmd.to_excel(temp_full_path + '\Matched_Webmd_Ind_Output.xlsx', index=False, header=True)
#
#             except Exception as e:
#
#                 traceback.print_exc(file=sys.stdout)
#
#         def Webmd_Organization():
#             try:
#
#                 search_Data1 = []
#
#                 Provider_Contact_Numb1 = []
#
#                 State1 = []
#
#                 State_Code1 = []
#                 Index = []
#
#                 org_List = []
#
#                 if 'FIRST NAME' in df.columns:
#                     individual_df = df['PROVIDER']
#                     org_df = pd.DataFrame()
#                 else:
#                     org_df = df['PROVIDER']
#
#                     for i in org_df.index:
#                         org_List.append(org_df[i].strip() + ' ' + df['STATE'][i].strip() + ' ' + 'WEBMD')
#                         Index.append(df['index_col'][i])
#
#                     for k in org_List:
#
#                         try:
#                             driver.get("https://google.com/")
#                             time.sleep(2)
#
#                             driver.minimize_window()
#
#                             driver.find_element_by_xpath("//*[@class='gLFyf']").send_keys(str(k))
#                             time.sleep(5)
#                             driver.find_element_by_xpath(
#                                 "/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]").submit()
#                             time.sleep(5)
#                             driver.find_element_by_xpath(
#                                 "//a[starts-with(@href, 'https://doctor.webmd.com/practice')][1]").click()
#                             driver.implicitly_wait(5)
#
#                             try:
#                                 name1 = driver.find_element_by_xpath(
#                                     "//*[@id='app']/main/div/div[1]/div/h3").text
#                                 search_Data1.append(name1)
#                             except:
#                                 search_Data1.append("")
#
#                             try:
#                                 st1 = driver.find_element_by_xpath(
#                                     "//*[@id='app']/main/div/div[2]/div[1]/div/div[3]/div/a/div[3]/div/span").text
#                                 State_Code1.append(st1)
#                             except:
#                                 State_Code1.append("")
#
#                             try:
#                                 cn1 = driver.find_element_by_xpath(
#                                     "//*[@id='app']/main/div/div[2]/div[2]/div/a/span").text
#                                 Provider_Contact_Numb1.append(cn1)
#                             except:
#                                 Provider_Contact_Numb1.append("")
#
#                             driver.implicitly_wait(10)
#
#                             driver.back()
#                         except:
#                             search_Data1.append("None")
#                             State_Code1.append("None")
#                             Provider_Contact_Numb1.append("None")
#
#                     Webmd_organization = {"PROVIDER": search_Data1, "ADDRESS": State1,
#                                           "Phone": Provider_Contact_Numb1, "index_col": Index}
#
#                     webmd_org = pd.DataFrame(Webmd_organization)
#
#                     webmd_org.to_excel(temp_full_path + "\Webmd_org.xlsx", index=False)
#                     df_output = pd.read_excel(temp_full_path + "\Webmd_org.xlsx")
#                     df_output['PROVIDER'] = df_output['PROVIDER'].str.upper()
#                     df_output['PROVIDER'] = df_output['PROVIDER'].apply(replace_abbreviations)
#
#                     df['PROVIDER'] = df['PROVIDER'].str.upper()
#                     df['PROVIDER'] = df['PROVIDER'].apply(replace_abbreviations)
#                     df['New'] = df['PROVIDER'].str.strip()
#                     df['New'] = df['New'].str.upper()
#                     df['New'] = df['PROVIDER'].replace('\s+', '', regex=True)
#                     df['New'] = df.New.apply(lambda ch: remove_char(ch))
#
#                     df_new = df['New']
#                     df_new = df_new.to_frame(name='New')
#                     df_new['New'] = df['New'].str.upper()
#                     df_new['index_col'] = df['index_col']
#                     df_new["New"] = df_new["New"].replace('\s+', '', regex=True)
#                     df_new['New'] = df_new.New.apply(lambda ch: remove_char(ch))
#
#                     final = pd.concat([df_new, df], axis=1)
#
#                     final = final.loc[:, ~final.columns.duplicated()]
#
#                     df_output['New'] = df_output['PROVIDER']
#                     df_output['New'] = df_output['New'].astype(str)
#                     df_output['New'] = df_output['New'].str.upper()
#                     df_output["New"] = df_output["New"].replace('\s+', '', regex=True)
#                     df_output["New"] = df_output.New.apply(lambda ch: remove_char(ch))
#
#                     Vlookup = pd.merge(df_new, df_output, on=['New', 'index_col'], how='inner')
#                     final_output = Vlookup.drop_duplicates()
#
#                     df_final = pd.merge(final, final_output, on=['New', 'index_col'], how='left')
#
#                     df_final = df_final.drop(["New"], axis=1)
#                     df_final.rename(columns={'STATE_x': 'STATE', 'PROVIDER_x': 'PROVIDER'}, inplace=True)
#
#                     df_ph = df_final.groupby('index_col')["Phone"].apply(lambda x: x.unique()).reset_index()
#
#                     df_add = df_final.groupby('index_col')["ADDRESS"].apply(lambda x: x.unique()).reset_index()
#
#                     df_webmd1 = pd.merge(df, df_ph, on='index_col', how='left')
#
#                     df_webmd1 = pd.merge(df_webmd1, df_add, on='index_col', how='left')
#                     df_webmd1 = df_webmd1.drop(['New'], axis=1)
#                     df_webmd1.rename(columns={'Phone': 'Webmd_Phone_No'}, inplace=True)
#
#                     df_webmd1.rename(columns={'ADDRESS': 'Webmd_Address'}, inplace=True)
#
#                     df_webmd1.to_excel(temp_full_path + '\Matched_Webmd_Org_Output.xlsx', index=False, header=True)
#
#                 end_time = datetime.now()
#                 print("Webmd Website Module completed successfully")
#
#                 labelc.configure(text="Webmd Website Module completed!")
#                 progress()
#                 root.update()
#
#
#
#             except Exception as e:
#                 labelc.configure(text="Webmd Website Module completed!", fg="brown")
#                 progress()
#                 root.update()
#                 traceback.print_exc(file=sys.stdout)
#
#         def Vitadox_individual():
#             try:
#                 print("\n****Vitadox Module has started****")
#                 i_List = []
#                 providername = []
#                 myphone = []
#                 State = []
#                 Index = []
#                 State_Code = []
#                 Lst = ["DBA", "INC", "LLC", "PLLC", "PC", "SC", "Inc", "P.C."]
#
#                 if 'FIRST NAME' in df.columns:
#                     individual_df = df['PROVIDER']
#                 else:
#                     org_df = df['PROVIDER']
#                     individual_df = pd.DataFrame()
#
#                 for i in individual_df.index:
#                     i_List.append(individual_df[i].strip() + ' ' + df['STATE'][i].strip() + ' ' + 'Vitadox')
#                     Index.append(df['index_col'][i])
#
#                 if 'FIRST NAME' in df.columns:
#                     for i in i_List:
#                         try:
#                             driver.get("https://google.com/")
#
#                             driver.minimize_window()
#                             driver.find_element_by_xpath("//*[@class='gLFyf']").send_keys(str(i))
#                             driver.find_element_by_xpath(
#                                 "/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]").submit()
#                             driver.find_element_by.xpath("//*[contains(@href, 'www.vitadox.com/')]").click()
#                             driver.implicitly_wait(10)
#
#                             Name = driver.find_element_by_xpath(
#                                 "/html/body/div[1]/main/div[2]/div/section[1]/div[1]/div[1]/div/h1").text
#
#                             Phone_no = driver.find_element_by_xpath(
#                                 "/html/body/div[1]/main/div[2]/div/section[1]/div[1]/div[2]/a").text
#
#                             try:
#                                 Address = driver.find_element_by_xpath(
#                                     "/html/body/div[1]/main/div[2]/div/section[1]/div[1]/div[1]/div/div/p[1]").text
#                             except:
#                                 Address = driver.find_element_by_xpath(
#                                     "/html/body/div[1]/main/div[2]/div/section[1]/div[1]/div[1]/div/p[1]").text
#
#                             providername.append(Name)
#                             myphone.append(Phone_no)
#                             State.append(Address)
#
#                             driver.implicitly_wait(5)
#
#                             driver.back()
#
#                         except:
#                             providername.append("No Result Found")
#                             myphone.append("No Result Found")
#                             State.append("No Result Found")
#                             driver.back()
#
#                     for j in State:
#
#                         if j == "No Result Found":
#                             State_Code.append("No Result Found")
#                             continue
#
#                         State_Code.append(j)
#
#                     Vitadox_individual_dct = {"PROVIDER": providername, "ADDRESS": State_Code,
#                                               "Phone": myphone, "index_col": Index}
#
#                     Vita_ind = pd.DataFrame(Vitadox_individual_dct)
#
#                     Vita_ind.to_excel(temp_full_path + "\Vita_ind.xlsx", index=False)
#
#                     df_output = Vita_ind
#
#                     df['New'] = df['PROVIDER'].str.strip()
#                     df['New'] = df['New'].astype(str)
#                     df['New'] = df['New'].str.upper()
#                     df_new = df['New']
#                     df_new = df_new.to_frame(name='New')
#                     df_new['New'] = df['New'].str.upper()
#                     df_new['index_col'] = df['index_col']
#                     final = pd.concat([df, df_new], axis=1)
#
#                     final = final.loc[:, ~final.columns.duplicated()]
#
#                     df_output["New"] = df_output['PROVIDER']
#
#                     df_output["New"] = df_output["New"].astype(str)
#                     df_output['New'] = df_output['New'].str.upper()
#
#                     pat_lname = f"({'|'.join(df['LAST NAME'])})"
#                     pat_fname = f"({'|'.join(df['FIRST NAME'])})"
#                     df_output['LAST NAME'] = df_output['New'].str.extract(pat=pat_lname)
#                     df_output['FIRST NAME'] = df_output['New'].str.extract(pat=pat_fname)
#                     df_output.loc[df_output['LAST NAME'].isna(), 'LAST NAME'] = np.NAN
#                     df_output.loc[df_output['FIRST NAME'].isna(), 'FIRST NAME'] = np.NAN
#                     Vlookup = df.merge(df_output, left_on=['LAST NAME', 'FIRST NAME'],
#                                        right_on=['LAST NAME', 'FIRST NAME'], how='left')
#                     Vlookup = Vlookup.drop(["PROVIDER_y", "New_x", "index_col_y", "New_y"], axis=1)
#
#                     df_final = Vlookup.drop_duplicates()
#                     df_final.rename(columns={'index_col_x': 'index_col', 'PROVIDER_x': 'PROVIDER'}, inplace=True)
#
#                     df_ph = df_final.groupby("index_col")["Phone"].apply(lambda x: x.unique()).reset_index()
#
#                     df_add = df_final.groupby("index_col")["ADDRESS"].apply(lambda x: x.unique()).reset_index()
#
#                     df_Vita = pd.merge(df, df_ph, on='index_col', how='left')
#
#                     df_Vita = pd.merge(df_Vita, df_add, on='index_col', how='left')
#                     df_Vita = df_Vita.drop(['New'], axis=1)
#                     df_Vita.rename(columns={'Phone': 'Vitadox_Phone_No'}, inplace=True)
#
#                     df_Vita.rename(columns={'ADDRESS': 'Vitadox_Address'}, inplace=True)
#                     df_Vita = df_Vita.fillna("")
#
#                     df_Vita.to_excel(temp_full_path + '\Matched_Vita_Ind_Output.xlsx', index=False, header=True)
#
#             except:
#                 traceback.print_exc(file=sys.stdout)
#
#         def Vitadox_Organization():
#             try:
#
#                 org_List = []
#                 providername1 = []
#                 myphone1 = []
#                 State1 = []
#                 Index = []
#                 State_Code1 = []
#                 Lst = ["DBA", "INC", "LLC", "PLLC", "PC", "SC", "Inc"]
#
#                 if 'FIRST NAME' in df.columns:
#                     individual_df = df['PROVIDER']
#                     org_df = pd.DataFrame()
#                 else:
#                     org_df = df['PROVIDER']
#
#                     for i in org_df.index:
#                         org_List.append(org_df[i].strip() + ' ' + df['STATE'][i].strip() + ' ' + 'Vitadox')
#                         Index.append(df['index_col'][i])
#
#                     for j in org_List.index:
#                         try:
#                             driver.get("https://google.com/")
#                             driver.minimize_window()
#
#                             driver.find_element_by_xpath("//*[@class='gLFyf']").send_keys(str(j))
#
#                             driver.find_element_by_xpath(
#                                 "/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]").submit()
#
#                             driver.find_element_by.xpath("//*[contains(@href, 'www.vitadox.com/')]").click()
#                             driver.implicitly_wait(10)
#
#                             Name1 = driver.find_element_by_xpath(
#                                 "/html/body/div[1]/main/div[2]/div/section[1]/div[1]/div[1]/div/h1").text
#
#                             Phone_no1 = driver.find_element_by_xpath(
#                                 "/html/body/div[1]/main/div[2]/div/section[1]/div[1]/div[2]/a").text
#
#                             Address1 = driver.find_element_by_xpath(
#                                 "/html/body/div[1]/main/div[2]/div/section[1]/div[1]/div[1]/div/p[1]").text
#
#                             providername1.append(Name1)
#                             myphone1.append(Phone_no1)
#
#                             State1.append(Address1)
#
#                             driver.implicitly_wait(5)
#
#                             driver.back()
#
#                         except:
#                             providername1.append("No Result Found")
#                             myphone1.append("No Result Found")
#                             State1.append("No Result Found")
#
#                     for j in State1:
#
#                         if j == "No Result Found":
#                             State_Code1.append("No Result Found")
#
#                             continue
#
#                         State_Code1.append(j)
#
#                     Vitadox_organization = {"PROVIDER": providername1, "ADDRESS": State_Code1,
#                                             "Phone": myphone1, "index_col": Index}
#
#                     Vita_org = pd.DataFrame(Vitadox_organization)
#
#                     Vita_org.to_excel(temp_full_path + "\Vita_org.xlsx", index=False)
#
#                     df_output = Vita_org
#                     df_output['PROVIDER'] = df_output['PROVIDER'].str.strip()
#                     df_output['PROVIDER'] = df_output['PROVIDER'].apply(replace_abbreviations)
#
#                     List1 = ["DBA", "INC", "LLC", "PLLC", "PC", "SC", "LMCH", ".", "P.C.", "Inc"]
#
#                     df['PROVIDER'] = df['PROVIDER'].str.upper()
#                     df['PROVIDER'] = df_output['PROVIDER'].apply(replace_abbreviations)
#                     df['New'] = df['PROVIDER'].str.strip()
#                     df['New'] = df['New'].astype(str)
#                     df['New'] = df['New'].str.upper()
#                     df['New'] = df['PROVIDER'].replace('\s+', '', regex=True)
#                     df['New'] = df.New.apply(lambda ch: remove_char(ch))
#
#                     df_new = df['New']
#                     df_new = df_new.to_frame(name='New')
#                     df_new['New'] = df['New'].str.upper()
#                     df_new['index_col'] = df['index_col']
#                     df_new["New"] = df_new["New"].replace('\s+', '', regex=True)
#                     df_new["New"] = df_new.New.apply(lambda ch: remove_char(ch))
#
#                     final = pd.concat([df, df_new], axis=1
#                                       )
#                     final = final.loc[:, ~final.columns.duplicated()]
#
#                     df_output["New"] = df_output['PROVIDER']
#                     df_output['New'] = df_output['New'].astype(str)
#                     df_output["New"] = df_output['New'].str.upper()
#                     df_output["New"] = df_output["New"].replace('\s+', '', regex=True)
#                     df_output["New"] = df_output.New.apply(lambda ch: remove_char(ch))
#
#                     Vlookup = pd.merge(df_new, df_output, on=['New', 'index_col'], how='inner')
#
#                     final_output = Vlookup.drop_duplicates()
#
#                     df_final = pd.merge(final, final_output, on=['New', 'index_col'], how='left')
#
#                     df_final = df_final.drop(["New"], axis=1)
#
#                     df_final.rename(columns={'STATE_x': 'STATE', 'PROVIDER_x': 'PROVIDER'}, inplace=True)
#
#                     df_ph = df_final.groupby("index_col")["Phone"].apply(lambda x: x.unique()).reset_index()
#
#                     df_add = df_final.groupby("index_col")["ADDRESS"].apply(lambda x: x.unique()).reset_index()
#
#                     df_Vita1 = pd.merge(df, df_ph, on='index_col', how='left')
#
#                     df_Vita1 = pd.merge(df_Vita1, df_add, on="index_col", how='left')
#                     df_Vita1 = df_Vita1.drop(['New'], axis=1)
#                     df_Vita1.rename(columns={'Phone': 'Vitadox_Phone_No'}, inplace=True)
#
#                     df_Vita1.rename(columns={'ADDRESS': 'Vitadox_Address'}, inplace=True)
#                     df_Vita1 = df_Vita1.fillna("")
#
#                     df_Vita1.to_excel(temp_full_path + '\Matched_Vita_Org_Output.xlsx', index=False, header=True)
#
#                 end_time = datetime.now()
#
#                 print("Vitadox Website Module completed successfully!")
#
#                 labeld.configure(text="Vitadox Website Module completed !")
#                 progress()
#                 root.update()
#
#             except:
#                 labeld.configure(text="Vitadox Website Module completed!", fg="brown")
#                 progress()
#                 root.update()
#                 traceback.print_exc(file=sys.stdout)
#
#                 def Healthgrades():
#             try:
#                 print("\n****Healthgrades Module has started***")
#                 Phone = []
#                 Address = []
#                 Name = []
#                 Index = []
#                 driver1 = webdriver.Chrome(executable_path='' + str(application_path) + '\chromedriver.exe')
#                 driver.minimize_window()
#
#                 if 'FIRST NAME' in df.columns:
#                     df_new = df['PROVIDER']
#                     org_df = pd.DataFrame()
#                 else:
#                     org_df = df['PROVIDER']
#                     df_new = pd.DataFrame()
#
#                 time.sleep(5)
#                 for i in df_new.index:
#                     try:
#                         driver1.get("https://www.healthgrades.com/")
#                         driver1.minimize_window
#
#                         "//*[@id='MegaMenuFindDoctorContainer']/a.click()"
#                     driver.implicitly_wait(5)
#                     zip_code = str(df['ZIP'][i])
#                     if len(zip_code) == 4:
#                         zip_code = '0' + str(zip_code)
#                     zip_code = df['STATE'][i] + " " + zip_code
#                     entry = df_new.loc[i]
#
#                     doc = driver.find_element_by_xpath(
#                         '/html/body/div[1]div/main/div/div[1]header/div[2]/div/form/div[1]/div/div[1]div/div/div/input')
#                     doc.send_Keys(str(entry))
#                     time.sleep(2)
#                     driver.find_element_by_xpath('/html/body/div[1]/div/main/div/div[1]/header/div[2]/div/form/div[1]/div/div[2]/div/div/div/input').send_keys.CONTROL + "a", Keys.BACKSPACE)
#
#                     time.sleep(2)
#
#                     driver.find_element_by_xpath('/html/body/div[1]/div/main/div/div[1]/header/div[2]/div/form/div[1]/div/div[2]/div/div/div/input").send_key(str(zip_code)
#                 time.sleep(2)
#                 driver.find_element_by_xpath(
#                     '//*[@id="hero-search-bar"]/div[1]/div/div[3]/div/button[2]').click()
#                 time.sleep(5)
#
#                 Index.append(df['index_col][i]))
#                 link = driver.find_element_by_xpath(
#
#                     '/html/body/div[2]/div[2]/main/div[4]/section/div/div/div[2]/ul/li[1]/div/div/div[2]/div[1]/div/a').get_attribute(
#                     "href")
#
#                 D_Name = driver.find_element_by_xpath(
#
#                     '/html/body/div[2]/div[2]/main/div[4]/section/div/div/div[2]/ul/li[1]/div/div[1]/div[1]/div[1]/h3/a').text
#
#                 try:
#                     driver1.get(link)
#                     Name.append(D_NAME)
#                     try:
#                         Add = driver1.find_element_by_xpath()
#
#                         '/html/body/div[3]/div[2]/div[1]/div[1]/div[2]/div/div/div[2]/div[1]/address').text
#
#                         Address.append(Add)
#
#             except:
#
#                 Address.append("")
#
#             try:
#
#                 link_resp_element = driver1.find_element_by_xpath("/html/body")
#                 Link_response = link_resp_element.text
#
#                 while ' ' in link response:
#
#                     Link
#                     response
#                     link_response.replace("", "")
#                 phone
#                 regex = re.compile("\(\d{3}\)\s+\d{3}-\d{4})
#
#                 match
#                 phone_regex.search(link_response)
#
#                 if match:
#
#                     Phone.append(match.group())
#
#                 else:
#
#                     Phone.append("")
#
#             except:
#
#                 Phone.append("")
#
#         except:
#
#         No = "No_Record_Found"
#
#         Name.append(No)
#
#         Address.append(No)
#
#         Phone.append(No)
#
#
# except:
#
# No = "No_Record_Found"
#
# Name.append(No)
#
# Address.append(No)
#
# Phone.append(No)
#
# for j in org_df.index:
#
#     try:
#
#         driver.get("https://www.healthgrades.com/")
#
#         driver.minimize_window()
#
#         find_hos = driver.find_element_by_xpath(
#
#             "//*[@id='MegaMenuFindHospitalContainer']/a").click()
#
#         driver.implicitly_wait(5)
#
#         time.sleep(5)
#
#         entry
#         org_df.loc[j]
#
#         zip_code = str(df['ZIP'][j])
#
#         if len(zip_code) == 4:
#             zip_code = '0' + str(zip_code)
#
#         zip_code = df['STATE'][j] + " " + zip_code
#
#         Org_name_input = driver.find_element_by_xpath(
#
#             '/html/body/div[1]/div/main/div/div[1]/header/div[2]/div/form/div[1]/div/div[1]/div/div/div/input')
#
#     Org_name_input.send_keys(str(entry))
#
#     driver.find_element_by_xpath(
#
#         '/html/body/div[1]/div/main/div/div[1]/header/div[2]/div/form/div[1]/div/div[2]/div/div/div/input').send_keys(
#
#         Keys.CONTROL + 'a', Keys.BACKSPACE)
#
#     time.sleep(2)
#
#     driver.find_element_by_xpath(
#
#     / html / body / div[1] / div / main / div / div[1] / header / div[2] / div / form / div[1] / div / div[
#         2] / div / div / div / input
#     ').send_keys(
#
#     str(
#
#         zip_code))
#
#     time.sleep(2)
#
#     driver.find_element_by_xpath(
#
#         '//*[@id="hero-search-bar"]/div[1]/div/div[3]/div/button[2]').click()
#     Index.append(df['index_col'][j]
#
#     try:
#         Link
#         driver.find_element_by_xpath(
#
#             '/html/body/div[1]/main/div[4]/section/div/div/div[2]/ul/li[1]/div/div/div[3]/a').get_attribute(
#
#             "href")
#
#     driver.get(link)
#
#     P_Name = driver.find_element_by
#     xpath(
#
#         '//*[@id="root"]/main/div[1]/div[2]/div[2]/h1').text
#
#     Add
#     driver1.execute_script(
#
#         "return document.querySelector('#root> main> div.hospital-right-rail > div > div.hospital-right-rail-content > div.hospital-right-rail-summary > div').textContent;")
#
#     Phn = driver1.execute_script(
#
#         "return document.querySelector('#root main> div.hospital-right-rail > div > div.hospital-right-rail-content > div.hospital-right-rail-summary > p:nth-child(4)').textContent;")
#
#     Name.append(P_Name)
#
#     Address.append(Add)
#
#     Phone.append(Phn)
#
# except:
#
# No = "No_Record Found"
#
# Name.append(No)
#
# Address.append(No)
#
# Phone.append(No)
#
#
#
#
#
#
# # driver.back()
#
# except:
#
# No
# "No_Record_Found"
#
# Name.append(No)
#
# Address.append(No)
#
# Phone.append(No)
#
# driver1.close()
#
# Healthgrade = {"PROVIDER": Name, "ADDRESS": Address,
#
#                "Phone": Phone, "index_col": Index}
#
# health = pd.DataFrame(Healthgrade)
#
# health.to
# excel(temp_full_path\Healthgrades.xlsx
# ", index=False)
#
# df_output
# pd.read_excel(temp_full_path + "\Healthgrades.xlsx")
#
# df_output['PROVIDER'] = df_output['PROVIDER').str.upper()
# df_output['PROVIDER'] = df_output['PROVIDER'].apply(replace_abbreviations)
#
# df['PROVIDER'] = df['PROVIDER'].str.upper()
#
# df['PROVIDER'] = df['PROVIDER'].apply(replace_abbreviations)
# df['New'] = df['PROVIDER'].str.strip()
# df['New'] = df['New'].str.upper()
#
# df_new = df['New']
#
# df
# new
# df_new.to_frame(name="New")
#
# df_new['New'] = df['New'].str.upper()
#
# df_new['index_col'] = df['index_col']
#
# df_output["New"] = df_output['PROVIDER']
#
# df_output["New"] = df_output['New'].str.upper()
#
# if (('FIRST NAME' in df.columns)):
#     df['New'] = df.New.apply(lambda ch: remove_char(ch))
# final = pd.concat([df, df_new], axis=1)
#
# final
# final.loc[:, final.columns.duplicated()]
#
# df_output["New"] = df_output.New.apply(lambda ch: remove_char(ch))
#
# pat_lname = "({'I'.join(df["
# LAST
# NAME
# '])})"
#
# pat_fname = f" ({'I'.join(df[FIRST NAME]"
#
# df_output['LAST NAME'] = df_output['New'].str.extract(pat=pat_lname)
#
# df_output['FIRST NAME'] = df_output[New].str.extract(pat=pat_fname)
#
# df_output.loc[df_output['LAST NAME].isna), LAST NAME'] = np.NAN
#
# df_output.loc[df_output['FIRST NAME ].isna(), '
# FIRST
# NAME] = np.NAN
#
# Vlookup = df.merge(df_output, left_on=['LAST NAME, FIRST NAME'],
#
#                    right_on=['LAST NAME, FIRST NAME], how='left')
#
#                              Vlookup = Vlookup.drop(["PROVIDER_y", "New_x", "index_col_y", "New_y"], axis=1)
#
# df
# final = Vlookup.drop_duplicates()
#
# df_final.rename(columns={'index_col_x': index_col", "PROVIDER_X': 'PROVIDER'), inplace=True)
#
#     df_ph = df_final.groupby("index_col")["Phone"].apply(lambda x: x.unique()).reset_index()
#
# df_add = df_final.groupby("index_col")["ADDRESS"].apply(lambda x: x.unique()).reset_index()
#
# df_Health = pd.merge(df, df_ph, on='index_col', how='left')
#
# df_Health = pd.merge(df_Health, df_add, on='index_col', how='left')
#
# df_Health = df_Health.drop(['New'], axis=1)
#
# df
# Health.rename(columns={'Phone': 'Healthgrade_Phone_No'}, inplace=True)
#
# df_Health.rename(columns={'ADDRESS: '
# Healthgrade_Address
# '}, inplace=True)
#
# df
# Health = df
# Health.fillna("")
#
# df
# Health.to_excel(temp_full_path + "\\Matched_Healthgrade_Output.xlsx, index=False, header=True)
#
# else:
#
# df_new["New"] = df_new["New"].replace('\s+', '', regex=True)
# df_output["New"] = df_output["New"].replace('\s+', '', regex=True)
# df['New'] = df['PROVIDER'].replace('\s+', '', regex=True)
# df_new['New'] = df_new.New.apply(lambda ch: remove_char(ch))
#
# df_output["New"] = df_output.New.apply(lambda ch: remove_char(ch))
# df['New'] = df.New.apply(lambda ch: remove_char(ch))
# final = pd.concat([df, df_new], axis=1)
# final
# final.loc[:, final.columns.duplicated()]
# Vlookup = pd.merge(df_new, df_output, on=['New', 'index_col'], how='inner')
# final
# output = Vlookup.drop_duplicates()
# df
# final = pd.merge(final, final_output, on=['New", "index_col'], how='left')
# df_final = df_final.drop(["New"], axis=1)
# df_final.rename(columns={'STATE_x: '
# STATE
# ', '
# PROVIDER_x: 'PROVIDER'}, inplace = True)
# df_ph = df_final.groupby("index_col")["Phone"].apply(lambda x: x.unique()).reset_index()
# df_add = df_final.groupby("index_col")["ADDRESS"].apply(lambda x: x.unique()).reset_index()
# df_Health = pd.merge(df, df_ph, on="index_col", how='left')
#
# df_Health = pd.merge(df_Health, df_add, on="index_col", how='left')
#
# df_Health = df_Health.drop(['New'], axis=1)
#
# df
# Health.rename(columns={'Phone': 'Healthgrade_Phone_No, inplace=True)
#
#                        df Health.rename(columns={'ADDRESS': 'Healthgrade_Address}, inplace=True)
#
#                                                  df Health = df_Health.fillna("")
#
# df
# Health.to_excel(temp_full_path + '\\Matched_Healthgrade_Output.xlsx, index=False, header=True)
#
# end_time = datetime.now()
#
# print("Healthgrades Website Module completed successfully!")
#
# labele.configure(text="Healthgrade Website Module completed!")
#
# progress()
#
# root.update()
#
# except Exception as e:
#
# labele.configure(text="Healthgrade Website Module completed!", fg="brown")
# progress()
# root.update()
# traceback.print_exc(file=sys.stdout)
#
#
# def psychology():
#     try:
#
#         print("\n***Psychology Today Module has started***")
#
#         start_time = datetime.now()
#
#         Phone = []  # Empty List to Store Phone Numbers
#
#         Address = []  # Empty List to Store Addresses from Search Results
#
#         Name = []  # Empty List to Store the Names from Search Results
#
#         Index = []  # Empty List to Store the index from Search Results as per the df
#
#         Index1 = []  # Empty List to Store the Loop value
#
#         zip = df['ZIP']
#
#         time.sleep(5)
#
#         for j in df['PROVIDER'].index:
#
#             k = str(df["ZIP"][j])
#
#             if len(k) == 4:
#                 k = '0' + str(k)
#
#             p = 0
#
#             p += (j + 1)
#
#             l = str(re.sub(regex_postfix_removal, ", df['PROVIDER'][j], re.IGNORECASE))
#             driver.get("https://www.psychologytoday.com/us/")
#
#             driver.maximize_window()
#
#             driver.find_element_by_xpath(
#
#                 '/html/body/div[2]/header/div/div[2]/div/div/div/div/div/div[1]/div[2]/form/div/div[2]/div[2]/input").send_keys(
#
#             str(
#
#                 k))
#
#             driver.find_element_by_xpath(
#
#                 '/html/body/div[2]/header/div/div[2]/div/div/div/div/div/div[1]/div[2]/form/div/div[2]/div[2]/button').click()
#
#             time.sleep(10)
#
#             driver.find_element_by_xpath(
#
#                 '/html/body/div/div/div/nav[1]/div/header/div[2]/div[2]/div[2]/input').send_keys(str(l))
#
#             time.sleep(10)
#
#             driver.find_element_by_xpath(
#
#                 '/html/body/div/div/div/nav[1]/div/header/div[2]/div[2]/div[2]/button').click()
#
#             Index.append(df['index_col"][j])
#
#             try:
#
#                 WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH,
#
#                                                                                 '/html/body/div/div/div/div[3]/div/div[4]/div')))
#
#                 for i in range(1, 10):
#
#                     m = str(i)
#
#                     try:
#
#                         driver.find_element_by_xpath(
#
#                             '/html/body/div/div/div/div[3]/div/div[4]/div[' + m + ']').click()
#
#                         try:
#
#                             WebDriverWait(driver, 15).until(EC.presence_of_element_located((By.XPATH,
#
#                                                                                             '//*[@id="profileContainer"]/div[2]/div/div[1]/div[1]/div[4]/div/span/span[2]/a')))
#
#                             name = driver.find_element_by_xpath(
#
#                                 '//*[@id="profileContainer"]/div[2]/div/div[1]/div[1]/div[1]/div[1]/div/div[1]/div/h1').text
#
#                             Name.append(name.strip())
#
#                             WebDriverWait(driver, 15).until(EC.presence_of_element_located((By.XPATH,
#
#                                                                                             '//*[@id="profileContainer"]/div[2]/div/div[1]/div[1]/div[4]/div/span/span[2]/a')))
#                             phn = driver.find_element_by_xpath(
#
#                                 '//*[@id="profileContainer"]/div[2]/div/div[1]/div[1]/div[4]/div/span/span[2]/a').text
#
#                             Phone.append(phn.strip())
#
#                             WebDriverWait(driver, 15).until(EC.presence_of_element_located((By.XPATH,
#
#                                                                                             '//*[@id="profileContainer"]/div[2]/div/div[1]/div[2]/div/div[2]/div[1]')))
#
#                             add = driver.find_element_by_xpath(
#                                 '//*[@id="profileContainer"]/div[2]/div/div[1]/div[2]/div/div[2]/div[1]').text
#
#                             Address.append(add[:((add.find('(')) - 1)])
#
#                             Index1.append(p)
#
#                             driver.back()
#
#                         except:
#
#                             No = "No Record_Found"
#
#                             Name.append(No)
#
#                             Address.append(No)
#
#                             Phone.append(No)
#
#                             Index1.append(p)
#
#                     except:
#                         break
#                     except:
#
#                         No = "No Record Found"
#
#                     Name.append(No)
#                     Address.append(No)
#                     Phone.append(No)
#                     Index1.append(p)
#
#         Psychology = {"PROVIDER": Name, "ADDRESS": Address, "Phone": Phone, "index_col": Index}
#
#         # print(Psychology)
#
#         psy = pd.DataFrame(Psychology)
#
#         psy.to_excel(temp_full_path + "\Psychology.xlsx", index=False)
#
#         df_output = pd.read_excel(temp_full_path + "\Psychology.xlsx")
#
#         df_output[PROVIDER] = df_output[PROVIDER].str.upper()
#
#         df_output[PROVIDER] = df_output[PROVIDER].apply(replace_abbreviations)
#
#         df['PROVIDER'] = df[PROVIDER
#         '1.str.upper()
#
#         df[PROVIDER] = df[PROVIDER
#         '1.apply(replace_abbreviations)
#
#         df['New'] = df[PROVIDER].str.strip()
#
#         df['New'] = df[New].str.upper()
#
#         df_new = df['New']
#
#         df_new
#         df_new.to_frame(name="New")
#
#         df_new['New'] = df[New].str.upper()
#
#         f_new['index_col'] = dfl
#         'index_col"]
#
#         # print(df_new. to_markd
#
#         df_output["New"] = df_output[PROVIDER]
#
#         df_output["New"] = df_output['New'].str.upper()
#
#         if (('FIRST NAME in df.columns)):
#
#              df['New'] = df.New.apply( lambda ch: remove_char (ch))
#
#         final = pd.concat([df, df_new], axis=1)
#
#         final
#         final.loc[:, final.columns.duplicated()]
#
#         df_output["New"] = df_output.New.apply(lambda ch: remove_char(ch))
#
#         pat_lname = "("
#         I
#         '.join(df["LAST NAME'])})"
#
#         pat_fname = "({'I'.join(df['FIRST NAME]))"
#
#         df_output["LAST NAME] = df_output['New'].str.extract(pat=pat_lname)
#
#         df_output['FIRST NAME] = df_output['
#         New
#         '].str.extract(pat=pat_fname)
#
#         df_output.loc[df_output['LAST NAME ].isna, '
#         LAST
#         NAME
#         '] = np.NAN
#
#         df_output.loc[df_output['FIRST NAME'].isna(), 'FIRST NAME] = np.NAN
#
#         Vlookup = df.merge(df_output, left
#         on = ['LAST NAME, FIRST NAME'],
#
#         right_on = ['LAST NAME, FIRST NAME'], how = 'left')
#         Vlookup = Vlookup.drop(["PROVIDER_y", "New_x", "index_col_y", "New_y"], axis=1)
#
#         df
#         final
#         Vlookup.drop_duplicates()
#
#         df
#         final
#         rename(columns={index_col_x
#         ": "
#         index_col
#         ", PROVIDER_x: 'PROVIDER'), inplace=True)
#
#         df_ph = df_final.groupby("index_col")["Phone"].apply(lambda x: x.unique()).reset_index
#
#         df_add = df_final.groupby("index_col")["ADDRESS"].apply(lambda x: x.unique()).reset_index()
#
#         df_psy = pd.merge(df, df_ph, on='index_col', how='left')
#
#         df
#         psy = pd.merge(df_psy, df_add, on='index_col', how='left')
#
#         df_psy = df_psy.drop(['New'], axis=1)
#
#         df_psy.rename(columns={'Phone': 'Psychology_Phone_No'}, inplace=True)
#
#         df_psy.rename(columns={'ADDRESS: '
#         Psychology_Address
#         '}, inplace=True)
#
#         df_psy
#         df_psy.fillna("")
#
#         df_psy.to_excel(temp_full_path + "\\Matched Psychology_Output.xlsx', index=False, header=True)
#
#         else:
#
#         df_new["New"] = df_new["New"].replace('\s+', ' ', regex=True)
#
#         df_output["New"] = df_output["New"].replace("\s+", "", regex=True)
#
#         df['New'] = df['PROVIDER'].replace('\s+*, **, regex=True)
#
#         df_new['New'] = df_new.New.apply(lambda ch: remove_char(ch))
#
#         df_output["New"] = df_output.New.apply(lambda ch: remove_char(ch))
#
#         df['New'] = df.New.apply(lambda ch: remove_char(ch))
#
#         final = pd.concat([df, df_new], axis=1)
#
#         final
#         final.loc[:, final.columns.duplicated()]
#
#         Vlookup = pd.merge(df_new, df_output, on=['New', 'index_col'], how='inner')
#
#         final
#         output = Vlookup.drop_duplicates()
#
#         df
#         final = pd.merge(final, final_output, on=['New', 'index_col'], how='left')
#
#         df_final = df_final.drop(["New"], axis=1)
#
#         df_final.rename(columns=('STATE_X': 'STATE', 'PROVIDER_X': 'PROVIDER'), inplace=True)
#
#         # print(of final to parkdown (3)
#
#         df_ph = df_final.groupby("index_col")["Phone"].apply(lambda x: x.unique()).reset_index()
#
#         # print(df_ph.to_markdown())
#
#         df_add = df_final.groupby('index_col")["ADDRESS"].apply(lambda x: x.unique()).reset_index()
#
#         df
#         psy = pd.merge(df, df_ph, on='index_col", how='
#         left
#         ')
#
#         df_psy = pd.merge(df_psy, df_add, on=index_col
#         ", how='left')
#
#         df_psy = df_psy.drop(['New'], axis=1)
#
#         df_psy.rename(columns={'Phone": "Psychology Phone_No'}, inplace=True)
#
#         df
#         psy.rename(columns={'ADDRESS: Psychology_Address}, inplace=True)
#
#         df_psy = df_psy.fillna("")
#
#         df_psy.to_excel(temp_full_path + '\\Matched Psychology_Output.xlsx', index=False, header=True)
#
#         end
#         time = datetime.now()
#
#         print("Psychologytoday Website Module completed successfully!")
#
#         labelf.configure(text="Psychologytoday Website Module completed !")
#
#         progress()
#
#         root.update()
#
#
#
#
#
#
#     except Exception as e:
#
#         labelf.configure(text="Psychologytoday Website Module completed!", fg="brown")
#
#         progress()
#
#         root.update()
#
#         traceback.print_exc(file - sys.stdout)
#
#
# def datamanipulation():
#     try:
#
#         print("\n***Datamanipulation has started***")
#
#         try:
#
#             NPPES_read = pd.read_excel(temp_full_path + "\\Matched_NPPES_Output.xlsx')
#
#             NPPES
#             read.PROVIDER
#             NPPES
#             read.PROVIDER.str.upper()
#
#             NPPES
#             read.NPPES_Address = (NPPES read.NPPES Address.str.strip('[]')).str.strip("''").str.replace(
#
#                 ',', '').str.strip('"')
#
#             NPPES
#             read.NPPES_Address
#             NPPES_read.NPPES_Address.str.replace("]\[", ", ")
#             NPPES
#             read.NPPES
#             Address
#             NPPES
#             read.NPPES
#             Address.str.replace("]\[", ";").str.replace('-', '')
#
#             # for i in range(len(NPPES_read. NPPES Address))2
#
#             NPPES
#             read.NPPES_Phone_No(
#
#                 (NPPES_read.NPPES Phone_No.str.strip('[]')).str.strip("''")).str.strip().str.strip('""').str.strip('-')
#
#             NPPES
#             read.NPPES_Phone_No = NPPES
#             read.NPPES
#             Phone_No.str.replace(" ", " ")
#
#             NPPES
#             read.NPPES
#             Phone
#             No = NPPES
#             read.NPPES
#             Phone_No.str.replace("],\[", ";")
#
#             NPPES
#             merge
#             NPPES
#             read[['PROVIDER', 'NPPES Phone_No', 'NPPES_Address', "index_col"]]
#
#         except:
#
#             traceback.print_exc(file=sys.stdout)
#
#             NPPES
#             merge = pd.DataFrame(columns=['PROVIDER', 'NPPES Phone_No', 'NPPES Address', "index_col"])
#
#         # input = pd.read_excel (input3.get(), sheet_name=current_var_get())
#
#         input = df
#
#         input.PROVIDER = input.PROVIDER.str.upper()
#
#         join1 = pd.merge(input, NPPES
#         merge, on = ['PROVIDER', "index_col"], how = 'left')
#
#         # working with Hippospace
#
#         try:
#
#             Ind_Read_Hipaa = pd.read_excel(temp_full_path + '\Matched_Hippa Ind_Output.xlsx')
#
#         except:
#
#             Ind_Read_Hipaa = pd.DataFrame(
#                 columns=['PROVIDER", "Hippaspace_Phone_No", "Hippaspace_Address", "index_col"])
#
#         try:
#
#             Org_Read
#             Hipaa = pd.read_excel(temp_full_path='\Matched Hippa_Org Output.xlsx')
#
#
#
#         except:
#
#             Org
#             Read
#             Hipaa
#             pd.DataFrame(columns=['PROVIDER', 'Hippaspace Phone No", "Hippaspace Address", "index_col"])
#                                   final Hipaa = pd.concat([Ind_Read Hipaa, Org_Read_Hipaa])
#
#             final
#             Hipaa.PROVIDER = final
#             Hipaa.PROVIDER.str.upper()
#
#             final
#             Hipaa.Hippaspace_Address = (
#
#                 (final_Hipaa.Hippaspace_Address.str.strip('[]').str.strip("''")).str.replace(',', '').str.replace('-',
#                                                                                                                   '')
#                 final Hipaa.Hippaspace_Phone_No = (
#
#                 (final Hipaa.Hippaspace Phone No.str.strip('[]')).str.strip("''")).str.strip()
#
#             final
#             Hipaa.Hippaspace_Phone
#             No
#             final
#             Hipaa.Hippaspace
#             Phone
#             No.str.replace('\W', '', regex=True)
#
#             # print(final Hipoo.to_markdown())
#
#             df
#             phone
#             Hipaa
#             final
#             Hipaa.groupby("index_col")[("Hippaspace Phone No')].apply(
#
#                                         lambda x: x.unique()).reset_index()
#
#             df_Hipaaspace = pd.merge(join1, df_phone_Hipaa, on="index_col", how='left')
#
#             hippa_add = final
#             Hipaa.groupby("index_col")["Hippaspace Address"].apply(
#
#                 Lambda
#             x: x.unique()).reset_index()
#
#             df_Hipaaspace
#             pd.merge(df
#             Hipaaspace, hippa_add, on = "index_col", how = 'left')
#
#             df_Hipaaspace.Hippaspace
#             Address = (
#
#                 df_Hipaaspace.Hippaspace Address.astype(str).str.strip([])).astype(str).str.lstrip(
#                 "nan' '").str.lstrip("'").str.rstrip('nan')
#
#             for i in range(len(df Hipaaspace.Hippaspace Address)):
#
#                 hyphen_idx = df_Hipaaspace.Hippaspace_Address[i].rfind("-")
#
#                 if hyphen
#             idx = -1:
#
#             df
#             Hipaaspace.loc[i, "Hippaspace Address'] df Hipaaspace.Hippaspace Address[1][:hyphen_idx]
#
#             else:
#
#             space_idx
#             df_Hipaaspace.Hippaspace
#             Address[i].rfind(' ', -5)
#
#             df
#             Hipaaspace.loc[i, 'Hippaspace Address'] = df
#             Hipaaspace.Hippaspace
#             Address[i][:space_idx]
#
#             df
#             Hipaaspace.Hippaspace
#             Phone_No = (
#
#                 df Hipaaspace.Hippaspace Phone_No.astype(str).str.strip('[]')).astype(str).str
#             .1
#             strip(
#
#                 "nan").str.lstrip("'")
#
#             # working with WebMD
#
#         try:
#
#             WebMD
#             Ind
#             Read = pd.read_excel(temp_full_path + \Matched_Webmd_Ind_Output.xlsx
#             ')
#
#         except:
#
#             WebMD
#             Ind_Read = pd.DataFrame(columns=['PROVIDER', 'Webmd_Phone_No', 'Webmd_Address","index_col"])
#
#         try:
#
#             WebMD
#             Org
#             Read = pd.read_excel(temp_full_path + '\Matched Webmd_Org Output.xlsx')
#
#         except:
#
#             WebMD
#             Org
#             Read = pd.DataFrame(columns=['PROVIDER', 'Webad Phone No', 'Webed Address","index_col"])
#
#                                          WebMD final pd.concat([WebMD Ind_Read, WebMD Org Read])
#                                          WebMD_final.PROVIDER = WebMD_final.PROVIDER.str.upper()
#
#             # WebMD final. Webad Address (WebMD final. Webad Address.str.strip('[])).str.strip("").str.replace(", ", ")
#
#             WebMD_final.Webmd_Address = (
#
#                 (WebMD_final.Webmd_Address.str.strip('[]').str.strip("''").str.replace(',', '').str.replace('-',
#                                                                                                             '').str.extract(
#
#                     '\D?\w.*)[0])
#
#                     WebMD final.Webmd_Phone_No = (WebHD_final.Webmd_Phone_No.str.strip('[]')).str.strip("''")
#             WebMD_final.Webmd_Phone_No
#             WebMD
#             final.Webmd_Phone_No.str.replace('\D', '', regex=True)
#             df_phone_webMD = WebMD_final.groupby("index_col")[('webmd_phone')].apply(
#                 Lambda
#             x: x.unique()).reset_index()
#
#             df_phone_webMD = WebMD
#             final.groupby("index_col")[('Webad_Phone No')].apply(
#                 lambda x: x.unique()).reset_index()
#
#             df_WebMd = pd.merge(df_Hipaaspace, df_phone_webMD, on="index_col", how='left')
#
#             df
#             WebMd = pd.merge(df
#             Hipaaspace, df_phone_webMD, on = "index_col", how = "left")
#             df
#             WebMd.Webmd
#             Address(df
#             WebMd.Webmd_Address.astype(str).str.strip('[]')).astype(str).str.lstrip(
#                 "nan''").str.lstrip("'")
#
#             df
#             WebMd.Webmd_Phone_No = (df WebMd.Webmd_Phone_No.astype(str).str.strip('[]')).astype(str).str.lstrip(
#                 "nan''").str.lstrip("'")
#
#             # Healthgrade module started
#
#         try:
#
#             health_read = pd.read_excel(temp_full_path + '\\Matched_Healthgrade_Output.xlsx")
#
#         except:
#
#             health_read = pd.DataFrame(columns=['PROVIDER', 'Healthgrade Phone_No', 'Healthgrade_Address","index_col"])
#
#                                                 health_read.PROVIDER = health_read.PROVIDER.str.upper()
#
#             health_read.Healthgrade_Address = (
#
#                 (health read.Healthgrade Address.str.strip('[]')).str.strip("''").str.replace(',', '').str.replace('-',
#                                                                                                                    '').str.extract(
#
#                 '(\D?\w.*)')[0])
#
#             health_read.Healthgrade
#             Phone
#             No = (health_read.Healthgrade_Phone No.str.strip('[]').str.strip("''")
#
#             health_read.Healthgrade_Phone_No = health_read.Healthgrade_Phone_No.str.replace('\W', '', regex=True)
#             df_phone_health = health_read.groupby("index_col")[('Healthgrade_Phone_No')].apply(
#                 lambda x: x.unique()).reset_index()
#
#             df_add_health = health_read.groupby("index_col")["Healthgrade_Address"].apply(
#                 Lambda
#             x: x.unique()).reset_index()
#
#             df_health_final = pd.merge(df_phone_health, df_add_health, on="index_col", how='left')
#             join4 = pd.merge(df_WebMd, df_health_final, on="index_col", how='left')
#             join4.Healthgrade_Address = (join4.Healthgrade_Address.astype(str).str.strip('[]')).astype(
#
#                 str).str.strip("''")
#
#             join4.Healthgrade_Phone_No = (join4.Healthgrade_Phone_No.astype(str).str.strip('[]')).astype(
#                 str).str.strip("''")
#
#         try:
#
#             psy_read = pd.read_excel(temp_full_path + Matched
#             Psychology_Output.xlsx
#             ')
#
#         except:
#
#             psy_read = pd.DataFrame(columns=['PROVIDER, Psychology Phone No', 'Psychology_Address", "index_col"])
#                                              psy_read.PROVIDER = psy_read.PROVIDER.str.upper()
#             psy_read.Psychology_Address = (psy_read.Psychology_Address.str.strip('[]')).str.strip("''").str.replace(',',
#                                                                                                                     '').str.replace(
#                 '-', '')
#
#             psy_read.Psychology_Address = (psy_read.Psychology_Address.astype(str).str.strip('[]')).astype(
#                 str).str.lstrip(
#
#                 "nan''").str.lstrip("'")
#
#             psy_read.Psychology_Phone_No = (
#
#                 psy_read.Psychology_phone_No.astype(str).str.strip('[]')).astype(str).str.lstrip(
#
#                 "nan").str.lstrip("'")
#
#             psy_read.Psychology_Phone_No = psy_read.Psychology_Phone_No.str.replace('\W', '', regex=True)
#
#             df_phone_phy = psy_read.groupby("index_col")[('Psychology Phone_No')].apply(
#                 lambda x: x.unique()).reset_index()
#
#             df_add_phy = psy_read.groupby("index_col")["Psychology_Address"].apply(
#                 lambda x: x.unique()).reset_index()
#
#             df_psy_final = pd.merge(df_phone_phy, df_add_phy, on="index_col", how='left')
#             join5 = pd.merge(join4, df_psy_final, on="index_col", how='left')
#             joins.Psychology_Address = (join5.Psychology_Address.astype(str).str.strip('[]')).astype(str).str.strip(
#                 "''")
#             join5.Psychology
#             Phone_No = (join5.Psychology Phone_No.astype(str).str.strip('[]')).astype(
#
#                 str).str.strip("''")
#             joins = join5.drop_duplicates(keep='first')
#
#             # ---- 2590
#
#             # start from 2652
#
#             join5 = join5.replace('nan', '')
#             join5.fillna("", inplace=True)
#
#             join5 = join5.loc[:, `joins.columns.duplicated()]
#             join5 = join5.drop_duplicates(subset='index_col', keep="last")
#             join5 = join5.drop(["PROVIDER_y"], axis=1)
#             join5.rename(columns=('PROVIDER_x': 'PROVIDER'), inplace=True)
#             join5 = join5[join5.PROVIDER.notna()]
#             Temp = join5[join5['PROVIDER'].duplicated() & join5['ZIP'].duplicated()]
#
#             temp = Temp.groupby('PROVIDER')[("ZIP")].apply(
#                 (lambda x: x.unique()).reset_index()
#
#             temp_final = pd.merge(join5, temp, on='PROVIDER', how='left')
#
#             # print(temp final.to string())
#
#             join5['Comments'] = np.where(
#
#                 (temp_final['ZIP_x'] == temp_final['ZIP_y']),
#
#                 "Duplicate Provider found in input sheet, Please review.", "")
#
#             join5 = join5.replace('nan', '')
#
#             join5.fillna("", inplace=True)
#
#             join5.to_excel(output_full_path + '\Provider_Data_Extracted.xlsx'.split('.xlsx')[0] + '.xlsx',
#                            index=False, header=True)
#
#             x2 = win32com.client.Dispatch("Excel.Application")
#
#             x2.Visible = False
#
#             x2.Workbooks.Open(Filename=os.path.join(os.getcwd(), "My Output_macro.xlsm"))
#
#             x2.Application.Run("My Output _macro.xlsm!Macro1")
#
#             x2.Application.quit()
#
#             del x2
#
#             scrubbed_df = pd.read_excel(os.path.join(os.getcwd(), r"Output_File/Provider_Data_Extracted.xlsx"))
#             scrubbed_df["SUITE"] = scrubbed_df["SUITE"].replace("", "")
#
#             scrubbed_df["input_address"] = ""
#
#             scrubbed_df["input_address"] = scrubbed_df["input_address"].replace('', '')
#
#             scrubbed_df.fillna("", inplace=True)
#
#             scrubbed_df["ZIP"] = scrubbed_df["ZIP"].astype(str).apply(lambda x: x.zfill(5) if len(x) == 4 else x)
#
#             scrubbed_df["input_address"] = scrubbed_df['STREET] + " " + scrubbed_df['
#             SUITE
#             '] + " " scrubbed_df[
#
#
#             # --- 2688
#
#             'CITY"] + " " + scrubbed_df['
#             STATE
#             '] + " " + scrubbed_df["ZIP"]
#
#             clean_address = Lambda
#             x: re.sub(r'\s+', ' ', x)
#
#             scrubbed_df["input_address"] = scrubbed_df["input_address"].apply(
#
#                 clean_address).str.upper()
#
#             # remove extra whitesapces and coverting into uppercase
#
#             address_df = scrubbed_df.loc[:,
#
#                          ["PROVIDER", "input_address", "NPPES Address", "Hippaspace_Address", "Webmd_Address",
#                           "Healthgrade_Address", "Psychology_Address"]]
#
#             # print(address_df.to_markdown ())
#
#             cols
#             to
#             clean = ["input_address", "NPPES_Address", "Hippaspace Address", "Webmd_Address", Address", "
#                      Psychology_Address"]
#
#                      address_df[cols_to_clean] = address_df[cols_to_clean].applymap(
#
#                 lambda x: x.upper() if isinstance(x, str) else x)
#
#             address_df.replace('nan', '')
#
#             address_df.fillna("", inplace=True)
#
#             address_df[cols_to_clean] = address_df[cols_to_clean].applymap(replace_abbreviations)
#
#             address_df.to_excel(os.path.join(os.getcwd(), r'Output File/Addresses.xlsx'),
#
#                                 index=False)
#
#             path = temp_full_path
#
#             # Confidence score section for phone number
#
#             temp_df = pd.read_excel(os.path.join(os.getcwd(), r"Output File\Provider_Data_Extracted.xlsx"))
#
#             conf_score_dict = {
#
#                 "PROVIDER": [x for x in temp.df.PROVIDER],
#
#                 "NPPES Score_Ph": [0 for i in range(len(temp_df.index))],
#
#                 "Hippaspace Score Ph": [0 for i in range(len(temp_df.index))],
#
#                 "WebMD Score_Ph": [0 for i in range(len(temp_df.index))],
#
#                 "Healthgrades Score Ph: [0 for i in range(len(temp_df.index))],
#
#                 "Psychology Score Ph": [0 for i in range(len(temp_df.index))],
#
#                 "Cumulative Score Ph": [0 for i in range(len(temp_df.index))],
#
#                 "Matched Score_Ph": [0 for i in range(len(temp_df.index))]
#
#             }
#
#             conf_score_df = pd.DataFrame(conf_score_dict)
#
#             conf_df = temp_df[["PROVIDER", "PHONE", "NPPES Phone_No", "Hippaspace_Phone_No", "Webmd_Phone_No",
#
#                                conf_df.to_excel(os.path.join(os.getcwd(), r'output_File/Phone.xlsx'),
#
#                                                 index=False)
#
#                                conf_df[["PROVIDER", "PHONE", "NPPES_Phone_No", "Hippaspace_Phone_No", "Webmd_Phone_No",
#                                         "Healthgrade_Phone_No", "Psychology_Phone_No"]] = conf_df[
#
#                 ["PROVIDER", "PHONE", "NPPES Phone_No", "Hippaspace_Phone_No", "Webmd_Phone_No", "Healthgrade_Phone_No",
#                  "Psychology Phone_No"]].replace('\D', '', regex=True)
#
#             conf_df.fillna("", inplace=True)
#
#             # print(conf.df)
#
#             for index, val in conf_df.iterrows():
#                 row_val = []
#
#             for i in range(len(val)):
#                 if
#             i > 1:
#
#             if val[i] != "":
#                 conf_score_df.iloc[index, i - 1] = 1
#
#             conf_score_df.iloc[index, i - 1] = 1
#
#             conf_score_df.iloc[index, -2] = conf_score_df.iloc[index, -2] + 1
#
#             # if (str(val[1])).strip() == (str(val[i])).strip():
#
#             if (str(val[i])).strip().find((str(val[1])).strip()) >= 0:
#                 conf_score_df.iloc[index, -1] = conf_score_df.iloc[index, -1] + 1
#
#             conf_score_df['index_col'] = range(1, len(temp_df) + 1)
#
#             cols
#             conf_score_df.columns.tolist()
#
#             cols = cols[-1:] + cols[:-1]
#
#             conf_score_df = conf_score_df[cols]
#
#             add_df = pd.read_excel(os.path.join(os.getcwd(), r"Output File\Addresses.xlsx"))
#
#             add_conf_score_dict = {
#
#                 "PROVIDER": [x for x in temp_df.PROVIDER],
#
#                 "NPPES Score_Add": [for i in range(len(temp_df.Index))],
#
#                 "Hippaspace Score_Add": [0 for i in range(len(temp_df.index))],
#
#                 "WebMD Score_Add": [0 for i in range(len(temp_df.index))],
#
#                 "Healthgrades Score_Add": [0 for i in range(len(temp_df.index))],
#
#                 "Psychology Score_Add": [0 for i in range(len(temp_df.index))],
#
#                 "Cumulative Score_Add": [0 for i in range(len(temp_df.index))],
#
#                 "Matched Score_Add": [0 for i in range(len(temp_df.index))]
#
#             }
#
#             add_conf_score_df = pd.DataFrame(add_conf_score_dict)
#
#             # print((pd.DataFrame(add_conf_score_dict)).to_markdown())
#
#             conf_df = add_df[
#                 ["PROVIDER", "input_address", "NPPES_Address", "Hippaspace_Address", "Webmd_Addre "Healthgrade_Address
#                  ", "Psychology_Address"]]
#
#                  conf_df[["PROVIDER", "input_address", "NPPES_Address", "Hippaspace_Address", "Webmd_Address",
#                           "Healthgrade_Address", "Psychology_Address", ]] = conf_df[
#
#                 ["PROVIDER", "input_address", "NPPES_Address", "Hippaspace_Address", "Webmd_Address",
#
#                  "Healthgrade_Address", "Psychology_Address"]].replace('\s+', '', regex=True)
#
#             conf_df.fillna("", inplace=True)
#
#             # print(conf_df)
#
#             for index, val in conf_df.iterrows():
#                 row_val = []
#
#             for i in range(len(val)):
#                 if
#             i
#             1:
#
#             if val[i] != "":
#                 add_conf_score_df.iloc[index, i - 1] = 1
#
#             add_conf_score_df.iloc[index, i - 1] = 1
#
#             add_conf_score_df.iloc[index, -2] = add_conf_score_df.iloc[index, -2] + 1
#
#             # if (str(val[1])).strip() == (str(val[1]) Istrip():
#
#             if (str(val[i])).strip().find((str(val[1])).strip()) >= 0:
#                 add_conf_score_df.iloc[index, -1] = add_conf_score_df.iloc[index, -1] + 1
#
#             add_conf_score_df['index_col"] = range (1, Len(add_df) + 1)
#
#             add_ph_conf_score_df = pd.merge(conf_score_df, add_conf_score_df, on='index_col', how='left')
#
#             add_ph_conf_score_df = add_ph_conf_score_df.drop(["PROVIDER_y"], axis=1)
#
#             add_ph_conf_score_df = pd.merge(conf_score_df, add_conf_score_df, on='index_col', how='left')
#
#             add_ph_conf_score_df = add_ph_conf_score_df.drop(["PROVIDER_y"], axis=1)
#
#             add_ph_conf_score_df.rename(columns={'PROVIDER_x': 'PROVIDER'}, inplace=True)
#
#             add_ph_conf_score_df["Confidence_Score_Ph"] = ""
#
#             add_ph_conf_score_df["Confidence_Score_Add"] = ""
#
#             add_ph_conf_score_df["Conf_Score_Ph"] = (add_ph_conf_score_df['Matched Score_Ph'] /
#
#                                                      add_ph_conf_score_df["Cumulative Score_Ph"]) * 100
#
#             add_ph_conf_score_df["Conf_Score_Ph"] = add_ph_conf_score_df["Conf_Score_Ph"].astype(str)
#
#             add_ph_conf_score_df["Conf_Score_Ph"] = add_ph_conf_score_df["Conf_Score_Ph"] + "%"
#
#             add_ph_conf_score_df["Conf_Score_Add"] = (add_ph_conf_score_df["Matched_Score_Add'] /
#
#                                                          add_ph_conf_score_df["Cumulative_Score_Add"]) + 100
#
#             add_ph_conf_score_df["Conf_Score_Add"] = add_ph_conf_score_df["Conf_Score_Add"].astype(str)
#
#             add_ph_conf_score_df["Conf_Score_Add"] = add_ph_conf_score_df["Conf_Score_Add"] + "%"
#
#             add_ph_conf_score_df["Conf_Score_Ph"] = add_ph_conf_score_df["Conf_Score_Ph"].replace('nan', '0.0%)
#
#             add_ph_conf_score_df["Conf_Score_Add"] = add_ph_conf_score_df["Conf_Score_Add"].replace('nan%', '0.0%)
#
#             add_ph_conf_score_df.loc[
#
#                 add_ph_conf_score_df['Cumulative Score Ph'] == 0, 'Confidence_Score_Ph'] = "unable to validate"
#
#             add_ph_conf_score_df.loc[add_ph_conf_score_df['Cumulative Score_Ph'] = 0, 'Confidence Score_Ph'] = \
#  \
#                     add_ph_conf_score_df["Conf_Score_Ph"]
#
#             add_ph_conf_score_df.loc[
#
#                 add_ph_conf_score_df['Cumulative Score_Add'] == 0, 'Confidence Score Add"] = "unable to validate"
#             add_ph_conf_score_df.loc[add_ph_conf_score_df['Cumulative Score Add'] = 0, 'Confidence Score_Add']= \
#                     add_ph_conf_score_df["Conf_Score_Add"]
#
#             conf_df
#             add_ph_conf_score_df[["PROVIDER", "Confidence Score_Ph", "Confidence Score_Add"]]
#
#             # print(conf_df)
#
#             add_ph.conf_score
#             df.to
#             excel(os.path.join(os.getcud(), "Output File\ConfidenceScore.xlsx"),
#
#                   index=False,
#
#                   header=True)
#
#             conf_df['PROVIDER'] = conf_df[PROVIDER].astype(str)
#
#             final_df_cons = pd.merge(temp_df, conf_df, on='PROVIDER', how='left')
#
#             final_df_cons = final_df_cons.drop_duplicates(subset='index_col', keep='first')
#
#             final_df_cons = final_df_cons.drop(
#                 ["index_col", 'New', 'Google_Search_Phone Number 1', 'Google_Search_Phone_Number_2'], axis=1)
#
#             final_df_cons.rename(columns={'Confidence_Score_Ph': 'Phone Confidence_Score',
#                                           'Confidence Score_Add': 'Address_Confidence_Score',
#                                           'Google_Search_Phone_Primary': 'Google_Search_Phone_No'}, inplace=True)
#
#             final_df_cons.to_excel(os.path.join(os.getcwd(), r"Output File\Provider_Data_Extracted Updated.xlsx"),
#
#                                    index=False,
#
#                                    header=True)
#
#             new_join
#             final_df_cons
#
#             new
#             join
#             new_join.drop(
#
#                 ['NPPES_Phone_No', 'NPPES Address', 'Hippaspace_Phone_No', 'Hippaspace Address', Webmd_Phone_No",
#                                                                                                                'Webmd_Address',
#                  'Healthgrade_Phone_No', 'Healthgrade_Address', 'Psychology Phone_No",
#                                                                 "Psychology_Address', 'Comments'], axis=1)
#
#                 for f in glob.iglob(path + '/**/*.xlsx', recursive=True):
#
#             os.remove(f)
#
#             clear
#             treeview()
#
#             tree["column"] = list(new_join.columns)
#
#             tree["show"] = "headings"
#
#             for col in tree["column"]:
#             # tree.column (col, stretch=NO)
#
#                 tree.heading(col, text=col)  # Put Data in Rows
#
#             df
#             rows = new_join.to_numpy().tolist()
#
#             for row in df_rows:
#                 tree.insert("", "end", values=row)
#
#             # messagebox.showinfo("Information Only", "Trocessing Completed")
#
#             labelh.configure(text="Final Result Prepared!")
#             labelz.configure(text="Current Status--Completed", fg="green")
#
#             progress()
#
#             root.update()
#
#             messagebox.showinfo("Information Only", "Processing Completed")
#
#             except Exception as e:
#
#             labelh.configure(text="Final Result Prepared!", fg="brown")
#
#             labelz.configure(text="Current Status--Completed with error", fg="green")
#
#             progress()
#
#             root.update()
#
#             traceback.print_exc(file=sys.stdout)
#
#             print(
#
#                 "We are having some issue while combining Outputs from Different Modules, Please Re-Run the
#             EXE
#             File
#             ") messagebox.showinfo("
#             Information
#             Only
#             ", "
#             Processing
#             Completed
#             with Error")
#             "Processing Completed with Error")
#
#         def cleanup_temp():
#
#             try:
#
#                 source_dir = temp_full_path
#
#                 archive_full_path = os.path.join(application_path, archive_file)
#
#                 file_names = os.listdir(source_dir)
#
#                 for file in file_names:
#                     shutil.move(os.path.join(source_dir, file), os.path.join(archive_full_path, file))
#
#             except Exception as e:
#
#                 traceback.print_exc(file=sys.stdout)
#
#         def cleanup_out():
#
#             try:
#
#                 source_dir = output_full_path
#
#                 archive_full_path = os.path.join(application_path, archive_file)
#
#                 file_names = os.listdir(source_dir)
#
#                 for file in file_names:
#
#                     if file != "Provider_Data_Extracted_Updated.xlsx":
#                         shutil.move(os.path.join(source_dir, file), os.path.join(archive_full_path, file))
#
#             except Exception as e:
#
#                 traceback.print_exc(file - sys.stdout)
#
#         if _name_ == "_main__":
#             Nppes()
#
#             Hippaspace
#             Individual()
#
#             Hippaspace
#             Organization()
#
#             Webmd
#             individual()
#
#             Webmd_organization()
#
#             Healthgrades()
#
#             psychology()
#
#             datamanipulation()
#
#             cleanup_temp()
#
#             cleanup_out()
#
#         print('\n' + str(filepath) + Processed
#         ')
#
#         end_time = datetime.now()
#
#         print("\n Total Script Execution time: {}".format(end_time - start_time))
#
#         end_time = datetime.now()
#
#         print("\n######Code run successful!#################")
#
#         print("\n Please open the Excel Files in the Output Folder!!!")
#
#         print("\n Total Script Execution time: {}".format(end_time - start_time))
#
#         driver.close()
#
        def detailview():

            try:

                input_df = pd.read_excel(output_full_path + '\\Provider_Data_Extracted_Updated.xlsx')

                df1 = pd.DataFrame(input_df)

                dfl.fillna("", inplace=True)

                clear_treeview()

                tree["column"] = list(df1.columns)

                tree["show"] = "headings"

                for col in tree["column"]:
                    tree.heading(col, text=col)

                df_rows = df1.to_numpy().tolist()

                for row in df_rows:
                    tree.insert("", "end", values=row)

            except Exception as e:

                traceback.print_exc(file - sys.stdout)

        label1 = tk.Label(root, text="Provider Data Search", font=("Cabbria 20 bold"), fg="magenta4", relief=FLAT)

        # exitbutton Button (root, text="Exit", width=10, bg="brown", fg="white", command-closeBtn)

        label2 = tk.Label(root, text="Enter Excel File Path", width = 20, bg="light green", font=("arial", 10, "bold"), )
        searchButton = tk.Button(root, text="Browse", width=15, height=1, bg="brown", fg="white", command = open_file)

        input3 = tk.Entry(root, textvariable - xl, width=80, state="disabled", disabledbackground="Light yellow")

        Label3 = tk.Label(root, text="Excel Sheet", width=20, font=("arial", 10, "bold"), bg="light green")

        sheetCombo = ttk.Combobox(root, textvariable = current_var, width=25, )

        sheetButton = tk.Button(root, text="Pick", width=12, bg="brown", fg="white", command=sheet_data)

        # headButton = tk.Button(root, text="Submit", width=15, bg="brown", fg="white", command= renameCol)

        Output = tk.Button(root, text="Export Output", width=15, bg="brown", fg="white", command=exportfile)

        Submit = tk.Button(root, text="Search Contact Info", width=15, bg="brown", fg="white", command=code_search)

        tblFrame = tk.Frame(root, bg="light yellow", bd=2, height=380, width=785, relief="groove")

        pb = ttk.Progressbar(root, orient=horizontal, mode=determinate , length=280, maximum=100, value=0)

        pb.place(x=190, y=500)

        value_label = Label(root, text - update_progress_label())

        value
        label.place(x=480, y=500)

        Labelx = tk.Label(root, width=65, font=("arial", 10))

        Labelz = tk.Label(root, font=("arial", 10, "bold"))

        labela = tk.Label(root, font=("arial", 8))

        labelb = tk.Label(root, font=("arial", 8))

        labelc = tk.Label(root, font=("arial", 8))

        labeld = tk.Label(root, font=("arial", 8))

        Labele = tk.Label(root, font=("arial", 8))

        Labelf = tk.Label(root, font=("arial", 8))

        Labelg = tk.Label(root, font=("arial", 8))

        Labelh = tk.Label(root, font=("arial", 8))

        detailedButton = tk.Button(root, text="Detailed View", width=15, bg="brown", fg="white", command=detailview)

        label1.place(x=2, y=7)

        # exitbutton.place(x=650, y=8)

        label2.place(x=7, y=46)
        searchButton.place(x=660, y=43)

        input3.place(x=175, y=46)

        Label3.place(x=7, y=75)

        sheetCombo.place(x=175, y=75)

        sheetButton.place(x=350, y=73)

        # label4.place(x=448,y=75)

        # hd.place(x=539,y=76)

        # headButton.place (x-630, y=73)

        labelx.place(x=30, y=680)

        Output.place(x=660, y=550)

        detailedButton.place(x=660, y=515)

        Submit.place(x=660, y=73)

        labelz.configure(text="Current Status")

        labelz.place(x=7, y=500)

        labela.place(x=7, y=520)

        labelb.place(x=7, y=540)

        labelc.place(x=7, y=560)

        labeld.place(x=7, y=580)

        labele.place(x=7, y=600)

        labelf.place(x=7, y=628)

        labelg.place(x=7, y=640)

        Labelh.place(x=7, y=660)

        tblFrame.place(x=7, y=100)

        tblFrame.pack_propagate(0)

        tblFrame.pack(padx=8, pady=115)

        xyz = 1

        tree = ttk.Treeview(tblFrame, columns=5, height=18)

        tree.bind("<ButtonRelease-1>", selectItem)

        root.mainloop()

except Exception as e:

    traceback.print_exc(file=sys.stdout)

